/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f0f5ff',
          100: '#e0ecff',
          200: '#c7dcfe',
          300: '#a3c5fd',
          400: '#75a3fc',
          500: '#487df8',
          600: '#2b5bf0',
          700: '#1e44dc',
          800: '#1a37b2',
          900: '#19308c',
          950: '#0c1a4e',
        },
        navy: {
          800: '#0f172a',
          850: '#0b1120',
          900: '#070d1e',
          950: '#030712',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'Consolas', 'monospace'],
      }
    },
  },
  plugins: [],
}
