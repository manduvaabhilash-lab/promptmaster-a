import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import LandingPage from './pages/LandingPage';
import DashboardPage from './pages/DashboardPage';
import LearnOverviewPage from './pages/LearnOverviewPage';
import TopicDetailPage from './pages/TopicDetailPage';
import ChatPage from './pages/ChatPage';
import PracticeLabPage from './pages/PracticeLabPage';
import PromptGeneratorPage from './pages/PromptGeneratorPage';
import PromptTypesPage from './pages/PromptTypesPage';
import LLMModelsPage from './pages/LLMModelsPage';
import StrategiesPage from './pages/StrategiesPage';
import OptimizationPage from './pages/OptimizationPage';
import EvaluationPage from './pages/EvaluationPage';
import BiasMitigationPage from './pages/BiasMitigationPage';
import CaseStudiesPage from './pages/CaseStudiesPage';
import QuizPage from './pages/QuizPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ProfilePage from './pages/ProfilePage';

export function App() {
  return (
    <Routes>
      {/* Platform pages wrapped in shared Layout */}
      <Route element={<Layout />}>
        <Route path="/" element={<LandingPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/learn" element={<LearnOverviewPage />} />
        <Route path="/learn/:topicId" element={<TopicDetailPage />} />
        <Route path="/chat" element={<ChatPage />} />
        <Route path="/practice" element={<PracticeLabPage />} />
        <Route path="/prompt-generator" element={<PromptGeneratorPage />} />
        <Route path="/prompt-types" element={<PromptTypesPage />} />
        <Route path="/llm-models" element={<LLMModelsPage />} />
        <Route path="/strategies" element={<StrategiesPage />} />
        <Route path="/optimization" element={<OptimizationPage />} />
        <Route path="/evaluation" element={<EvaluationPage />} />
        <Route path="/bias" element={<BiasMitigationPage />} />
        <Route path="/case-studies" element={<CaseStudiesPage />} />
        <Route path="/quiz" element={<QuizPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/profile" element={<ProfilePage />} />
      </Route>

      {/* Catch-all redirect */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;
