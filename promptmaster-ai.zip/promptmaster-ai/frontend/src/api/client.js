import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 60000,
});

// Request interceptor attaches JWT bearer token if available
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('promptmaster_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor handles friendly error messaging
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error.response?.data?.detail ||
      error.message ||
      'An unexpected network error occurred. Please verify backend is running.';
    return Promise.reject(new Error(message));
  }
);

export default api;
