import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../api/client';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      const token = localStorage.getItem('promptmaster_token');
      if (token) {
        try {
          const res = await api.get('/profile');
          if (!res.data.is_guest) {
            setUser(res.data);
          } else {
            localStorage.removeItem('promptmaster_token');
            setUser(null);
          }
        } catch {
          localStorage.removeItem('promptmaster_token');
          setUser(null);
        }
      }
      setLoading(false);
    };

    fetchUser();
  }, []);

  const login = async (email, password) => {
    const res = await api.post('/auth/login', { email, password });
    localStorage.setItem('promptmaster_token', res.data.access_token);
    setUser(res.data.user);
    return res.data;
  };

  const register = async (name, email, password) => {
    const res = await api.post('/auth/register', { name, email, password });
    localStorage.setItem('promptmaster_token', res.data.access_token);
    setUser(res.data.user);
    return res.data;
  };

  const logout = () => {
    localStorage.removeItem('promptmaster_token');
    setUser(null);
  };

  // Demo user login for fast testing
  const loginAsDemo = async () => {
    try {
      return await login('demo@promptmaster.ai', 'demo1234');
    } catch {
      // If demo account doesn't exist, create it automatically
      return await register('Demo Student', 'demo@promptmaster.ai', 'demo1234');
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, loginAsDemo }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
