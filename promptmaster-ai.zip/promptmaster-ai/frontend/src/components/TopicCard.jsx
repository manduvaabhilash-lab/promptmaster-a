import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { BookOpen, MessageSquare, ArrowRight, Clock, Award } from 'lucide-react';
import Badge from './Badge';

export const TopicCard = ({ topic }) => {
  const navigate = useNavigate();

  const handleAskAI = (e) => {
    e.preventDefault();
    e.stopPropagation();
    navigate(`/chat?topic=${encodeURIComponent(topic.title)}`);
  };

  return (
    <div className="glass-card glass-card-hover rounded-2xl p-6 flex flex-col justify-between border border-slate-800 relative group overflow-hidden">
      {/* Decorative gradient glow on hover */}
      <div className="absolute -top-24 -right-24 w-48 h-48 bg-brand-500/10 rounded-full blur-3xl pointer-events-none group-hover:bg-brand-500/20 transition-all duration-300" />

      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-7 h-7 rounded-lg bg-brand-500/20 text-brand-400 font-bold text-xs">
              0{topic.number}
            </span>
            <Badge color="blue">{topic.badge}</Badge>
          </div>
          <span className="flex items-center gap-1 text-xs text-slate-400">
            <Clock className="w-3.5 h-3.5" />
            {topic.reading_time}
          </span>
        </div>

        <h3 className="text-xl font-bold text-white group-hover:text-brand-300 transition-colors mb-1.5">
          {topic.title}
        </h3>
        <p className="text-xs text-brand-400 font-medium mb-3">
          {topic.subtitle}
        </p>

        <p className="text-sm text-slate-300 leading-relaxed mb-5 line-clamp-3">
          {topic.overview}
        </p>
      </div>

      <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-2 mt-auto">
        <button
          onClick={handleAskAI}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-700/80 border border-slate-700/60 transition"
          title="Ask AI about this topic"
        >
          <MessageSquare className="w-3.5 h-3.5 text-brand-400" />
          <span>Ask AI</span>
        </button>

        <Link
          to={`/learn/${topic.id}`}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 transition shadow-lg shadow-brand-600/20"
        >
          <span>Explore Topic</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
};

export default TopicCard;
