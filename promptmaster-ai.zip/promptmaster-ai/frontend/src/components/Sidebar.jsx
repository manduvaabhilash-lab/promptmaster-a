import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  Sparkles,
  LayoutDashboard,
  BookOpen,
  MessageSquare,
  FlaskConical,
  Wand2,
  Layers,
  Cpu,
  Compass,
  Sliders,
  CheckSquare,
  ShieldCheck,
  Briefcase,
  HelpCircle,
  User,
  LogOut,
  LogIn,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
  { name: 'Learn Modules', path: '/learn', icon: BookOpen },
  { name: 'AI Chat', path: '/chat', icon: MessageSquare },
  { name: 'Prompt Lab', path: '/practice', icon: FlaskConical },
  { name: 'Prompt Generator', path: '/prompt-generator', icon: Wand2 },
  { name: 'Prompt Types', path: '/prompt-types', icon: Layers },
  { name: 'LLM Models', path: '/llm-models', icon: Cpu },
  { name: 'Strategies', path: '/strategies', icon: Compass },
  { name: 'Optimization', path: '/optimization', icon: Sliders },
  { name: 'Evaluation', path: '/evaluation', icon: CheckSquare },
  { name: 'Bias & Safety', path: '/bias', icon: ShieldCheck },
  { name: 'Case Studies', path: '/case-studies', icon: Briefcase },
  { name: 'Quiz System', path: '/quiz', icon: HelpCircle },
];

export const Sidebar = ({ isOpen, onClose }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
    if (onClose) onClose();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm lg:hidden"
          onClick={onClose}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-900/95 lg:bg-slate-900/80 backdrop-blur-xl border-r border-slate-800 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800">
          <NavLink
            to="/"
            onClick={onClose}
            className="flex items-center gap-2.5 text-lg font-bold text-white group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-brand-600 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-brand-500/30 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-white tracking-tight">Prompt</span>
              <span className="text-brand-400">Master</span>
              <span className="text-xs px-1.5 py-0.5 ml-1.5 rounded bg-brand-500/20 text-brand-300 font-mono">
                AI
              </span>
            </div>
          </NavLink>
          {onClose && (
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Navigation list */}
        <div className="flex-1 px-3 py-4 overflow-y-auto space-y-1">
          <div className="px-3 pb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Platform Modules
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                  }`
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.name}</span>
              </NavLink>
            );
          })}
        </div>

        {/* User Account / Auth footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/40">
          {user ? (
            <div className="space-y-2">
              <NavLink
                to="/profile"
                onClick={onClose}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2 rounded-xl text-sm transition ${
                    isActive ? 'bg-slate-800 text-brand-400 font-semibold' : 'text-slate-300 hover:bg-slate-800/60'
                  }`
                }
              >
                <div className="w-7 h-7 rounded-full bg-brand-500/20 text-brand-300 flex items-center justify-center font-bold text-xs">
                  {user.name ? user.name[0].toUpperCase() : 'U'}
                </div>
                <div className="overflow-hidden flex-1">
                  <p className="text-xs font-semibold text-white truncate">{user.name}</p>
                  <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
                </div>
              </NavLink>
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out</span>
              </button>
            </div>
          ) : (
            <div className="space-y-1.5">
              <NavLink
                to="/login"
                onClick={onClose}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 transition shadow-md shadow-brand-600/20"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In / Demo</span>
              </NavLink>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
