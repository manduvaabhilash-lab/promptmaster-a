import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, Sparkles, MessageSquare, FlaskConical, User, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import api from '../api/client';

export const Navbar = ({ onOpenSidebar }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [llmStatus, setLlmStatus] = useState({ configured: false, loading: true });

  useEffect(() => {
    const checkHealth = async () => {
      try {
        const res = await api.get('/health');
        setLlmStatus({ configured: res.data.llm_configured, loading: false });
      } catch {
        setLlmStatus({ configured: false, loading: false });
      }
    };
    checkHealth();
  }, []);

  return (
    <header className="sticky top-0 z-30 h-16 bg-slate-900/80 backdrop-blur-xl border-b border-slate-800 flex items-center justify-between px-4 sm:px-8">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenSidebar}
          className="lg:hidden p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="hidden sm:flex items-center gap-2 text-xs">
          <span className="flex h-2 w-2 relative">
            <span
              className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                llmStatus.configured ? 'bg-emerald-400' : 'bg-brand-400'
              }`}
            ></span>
            <span
              className={`relative inline-flex rounded-full h-2 w-2 ${
                llmStatus.configured ? 'bg-emerald-500' : 'bg-brand-500'
              }`}
            ></span>
          </span>
          <span className="text-slate-400">
            {llmStatus.configured ? 'OpenAI LLM Connected' : 'PromptMaster Knowledge Engine Active'}
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Link
          to="/chat"
          className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 transition"
        >
          <MessageSquare className="w-3.5 h-3.5 text-brand-400" />
          <span>Ask AI</span>
        </Link>

        <Link
          to="/practice"
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 shadow-md shadow-brand-600/20 transition"
        >
          <FlaskConical className="w-3.5 h-3.5" />
          <span>Practice Lab</span>
        </Link>

        {user ? (
          <Link
            to="/profile"
            className="flex items-center gap-2 pl-2 pr-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700/60 text-xs font-medium text-white transition"
          >
            <div className="w-6 h-6 rounded-full bg-brand-500/20 text-brand-300 flex items-center justify-center font-bold text-xs">
              {user.name ? user.name[0].toUpperCase() : 'U'}
            </div>
            <span className="hidden sm:inline">{user.name.split(' ')[0]}</span>
          </Link>
        ) : (
          <Link
            to="/login"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition"
          >
            <User className="w-4 h-4" />
            <span>Sign In</span>
          </Link>
        )}
      </div>
    </header>
  );
};

export default Navbar;
