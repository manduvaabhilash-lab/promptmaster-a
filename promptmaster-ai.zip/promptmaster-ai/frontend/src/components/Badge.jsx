import React from 'react';

const colorStyles = {
  blue: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
  emerald: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  amber: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  purple: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
  rose: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
  indigo: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30',
  slate: 'bg-slate-700/30 text-slate-300 border-slate-600/40',
};

export const Badge = ({ children, color = 'blue', className = '' }) => {
  const style = colorStyles[color] || colorStyles.blue;
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${style} ${className}`}
    >
      {children}
    </span>
  );
};

export default Badge;
