import React from 'react';
import { Link } from 'react-router-dom';
import {
  Sparkles,
  BookOpen,
  MessageSquare,
  FlaskConical,
  Wand2,
  CheckSquare,
  Globe,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Layers,
  Award,
  Zap
} from 'lucide-react';
import Badge from '../components/Badge';

export const LandingPage = () => {
  const features = [
    {
      icon: BookOpen,
      title: 'Structured Curriculum',
      desc: '7 comprehensive modules covering token mechanics, in-context learning, few-shot schemas, and bias reduction.',
      badge: 'Learn',
      color: 'blue',
      link: '/learn',
    },
    {
      icon: MessageSquare,
      title: 'Educational AI Chatbot',
      desc: 'Ask questions to an AI tutor designed specifically to teach prompt engineering with practical examples.',
      badge: 'Ask AI',
      color: 'indigo',
      link: '/chat',
    },
    {
      icon: FlaskConical,
      title: 'Prompt Practice Lab',
      desc: 'Solve real-world challenges. Receive instant automated scoring across Clarity, Context, Constraints, and Output Format.',
      badge: 'Practice',
      color: 'emerald',
      link: '/practice',
    },
    {
      icon: Wand2,
      title: 'Prompt Generator & Optimizer',
      desc: 'Transform raw queries into production-grade prompts using role framing, task decomposition, and XML delimiters.',
      badge: 'Optimize',
      color: 'amber',
      link: '/prompt-generator',
    },
    {
      icon: CheckSquare,
      title: 'AI Response Evaluation',
      desc: 'Audit model outputs for hallucination risk, factual grounding, safety guardrails, and stereotyping.',
      badge: 'Evaluate',
      color: 'rose',
      link: '/evaluation',
    },
    {
      icon: Globe,
      title: 'Industry Case Studies',
      desc: 'Explore proven prompt patterns across Healthcare, Software Engineering, Fintech, and Customer Support.',
      badge: 'Apply',
      color: 'purple',
      link: '/case-studies',
    },
  ];

  const topicsPreview = [
    { num: '01', title: 'Prompt Engineering Fundamentals', tag: 'Core Foundational', link: '/learn/fundamentals' },
    { num: '02', title: 'LLM Models & Architecture', tag: 'Transformers & Tokens', link: '/learn/llm-models' },
    { num: '03', title: 'Types of Prompts & Applications', tag: 'Zero/Few-Shot & JSON', link: '/learn/prompt-types' },
    { num: '04', title: 'Effective Prompting Strategies', tag: 'Chain-of-Thought', link: '/learn/strategies' },
    { num: '05', title: 'Fine-Tuning & Optimization', tag: 'RAG & Hyperparameters', link: '/learn/optimization' },
    { num: '06', title: 'Evaluation & Bias Mitigation', tag: 'Safety & Hallucinations', link: '/learn/evaluation' },
    { num: '07', title: 'Real-World Applications & Case Studies', tag: 'Enterprise Playbooks', link: '/learn/case-studies' },
  ];

  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section */}
      <section className="relative text-center pt-8 sm:pt-16 max-w-4xl mx-auto space-y-6">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs font-semibold animate-pulse">
          <Sparkles className="w-3.5 h-3.5 text-brand-400" />
          <span>Interactive AI Educational Platform</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight">
          Master Prompt Engineering <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-brand-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
            with AI
          </span>
        </h1>

        <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed">
          Learn how to design effective prompts, understand LLMs, evaluate AI responses,
          and apply prompt engineering to real-world problems.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          <Link
            to="/learn"
            className="flex items-center gap-2 px-7 py-3.5 rounded-2xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-sm shadow-xl shadow-brand-600/30 hover:shadow-brand-500/40 transition-all transform hover:-translate-y-0.5"
          >
            <BookOpen className="w-4 h-4" />
            <span>Start Learning</span>
          </Link>

          <Link
            to="/chat"
            className="flex items-center gap-2 px-7 py-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white font-semibold text-sm border border-slate-700/80 shadow-lg transition-all transform hover:-translate-y-0.5"
          >
            <MessageSquare className="w-4 h-4 text-brand-400" />
            <span>Ask AI</span>
          </Link>

          <Link
            to="/practice"
            className="flex items-center gap-2 px-7 py-3.5 rounded-2xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white font-medium text-sm border border-slate-700/50 transition"
          >
            <FlaskConical className="w-4 h-4 text-emerald-400" />
            <span>Practice Lab</span>
          </Link>
        </div>

        {/* Live Prompt Preview Showcase */}
        <div className="mt-12 text-left glass-card rounded-2xl p-5 border border-slate-800 shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs text-slate-400">
            <span className="flex items-center gap-2 font-mono">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80 inline-block"></span>
              <span className="ml-2 text-slate-300 font-semibold">Live Comparison: Naive vs Mastered Prompting</span>
            </span>
            <Badge color="blue">Interactive Preview</Badge>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
            <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-900/30">
              <div className="text-xs font-semibold text-rose-400 mb-1">❌ Naive Prompt</div>
              <p className="font-mono text-xs text-slate-300">"Explain machine learning to me."</p>
              <div className="mt-2 text-[11px] text-slate-400">
                Result: Unpredictable length, conversational fluff, and unclear target audience.
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-emerald-950/20 border border-emerald-900/30">
              <div className="text-xs font-semibold text-emerald-400 mb-1">✅ PromptMaster Prompt</div>
              <p className="font-mono text-xs text-slate-200">
                "You are an NLP professor. Explain machine learning to a first-year student using a cooking recipe analogy, 3 bullet points, and 1 limitation."
              </p>
              <div className="mt-2 text-[11px] text-emerald-300/80">
                Result: Surgical clarity, structured constraints, and perfect pedagogical depth.
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Cards Grid */}
      <section className="space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-white">Comprehensive Learning Pillars</h2>
          <p className="text-slate-400 text-sm max-w-xl mx-auto">
            Everything you need to progress from intuitive prompting to production-grade AI engineering.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat) => {
            const Icon = feat.icon;
            return (
              <Link
                key={feat.title}
                to={feat.link}
                className="glass-card glass-card-hover rounded-2xl p-6 border border-slate-800 flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-brand-500/10 text-brand-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <Badge color={feat.color}>{feat.badge}</Badge>
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-brand-300 transition-colors mb-2">
                    {feat.title}
                  </h3>
                  <p className="text-sm text-slate-300 leading-relaxed mb-4">
                    {feat.desc}
                  </p>
                </div>
                <div className="flex items-center gap-1.5 text-xs font-semibold text-brand-400 group-hover:text-brand-300 transition-colors">
                  <span>Explore Feature</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Topics Overview */}
      <section className="space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl font-bold text-white">Curriculum Modules</h2>
            <p className="text-slate-400 text-sm">
              7 progressive topics taking you from foundational concepts to advanced industry applications.
            </p>
          </div>
          <Link
            to="/learn"
            className="flex items-center gap-1 text-sm font-semibold text-brand-400 hover:text-brand-300 transition"
          >
            <span>View All Modules</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {topicsPreview.map((t) => (
            <Link
              key={t.num}
              to={t.link}
              className="glass-card glass-card-hover rounded-xl p-4 border border-slate-800 flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <span className="w-8 h-8 rounded-lg bg-slate-800 text-brand-400 font-mono text-xs font-bold flex items-center justify-center group-hover:bg-brand-600 group-hover:text-white transition-colors">
                  {t.num}
                </span>
                <div>
                  <h4 className="text-sm font-bold text-white group-hover:text-brand-300 transition-colors">
                    {t.title}
                  </h4>
                  <span className="text-[11px] text-slate-400">{t.tag}</span>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-brand-400 group-hover:translate-x-1 transition" />
            </Link>
          ))}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="glass-card rounded-3xl p-8 sm:p-12 border border-slate-800 space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl sm:text-3xl font-bold text-white">How PromptMaster AI Works</h2>
          <p className="text-slate-400 text-sm max-w-lg mx-auto">
            A continuous four-stage feedback loop engineered for rapid skill mastery.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="space-y-3 p-4 rounded-xl bg-slate-900/50 border border-slate-800">
            <span className="w-8 h-8 rounded-full bg-brand-500/20 text-brand-300 font-bold text-sm flex items-center justify-center">
              1
            </span>
            <h4 className="font-semibold text-white">Learn Concepts</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Read focused modules on tokenization, in-context learning, and hyperparameter tuning.
            </p>
          </div>

          <div className="space-y-3 p-4 rounded-xl bg-slate-900/50 border border-slate-800">
            <span className="w-8 h-8 rounded-full bg-brand-500/20 text-brand-300 font-bold text-sm flex items-center justify-center">
              2
            </span>
            <h4 className="font-semibold text-white">Interact with AI</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Ask deep questions to the PromptMaster educational tutor with multi-turn context.
            </p>
          </div>

          <div className="space-y-3 p-4 rounded-xl bg-slate-900/50 border border-slate-800">
            <span className="w-8 h-8 rounded-full bg-brand-500/20 text-brand-300 font-bold text-sm flex items-center justify-center">
              3
            </span>
            <h4 className="font-semibold text-white">Practice in the Lab</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Draft prompts against real challenges and receive immediate scores across 5 dimensions.
            </p>
          </div>

          <div className="space-y-3 p-4 rounded-xl bg-slate-900/50 border border-slate-800">
            <span className="w-8 h-8 rounded-full bg-brand-500/20 text-brand-300 font-bold text-sm flex items-center justify-center">
              4
            </span>
            <h4 className="font-semibold text-white">Evaluate & Refine</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Audit AI responses for hallucination risk and apply bias-reduction frameworks.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-brand-400" />
          <span className="font-semibold text-white">PromptMaster AI</span>
          <span>— Learn. Prompt. Practice. Optimize.</span>
        </div>
        <div className="flex items-center gap-4">
          <Link to="/learn" className="hover:text-white transition">Curriculum</Link>
          <Link to="/chat" className="hover:text-white transition">AI Chat</Link>
          <Link to="/practice" className="hover:text-white transition">Practice Lab</Link>
          <Link to="/quiz" className="hover:text-white transition">Quiz System</Link>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
