import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Send,
  Plus,
  Trash2,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  Bot,
  User,
  Clock,
  ChevronRight,
  ShieldCheck,
  MessageSquare
} from 'lucide-react';
import api from '../api/client';
import LoadingSpinner from '../components/LoadingSpinner';
import Badge from '../components/Badge';

export const ChatPage = () => {
  const [searchParams] = useSearchParams();
  const initialTopic = searchParams.get('topic');
  const initialConvId = searchParams.get('c');

  const [conversations, setConversations] = useState([]);
  const [currentConversationId, setCurrentConversationId] = useState(
    initialConvId ? parseInt(initialConvId) : null
  );
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [copiedId, setCopiedId] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  const suggestedPrompts = [
    'What is zero-shot vs few-shot prompting?',
    'How do I write an effective system prompt?',
    'Explain Chain-of-Thought with a math example.',
    'How do I reduce hallucinations in LLM outputs?',
    'When should I use fine-tuning instead of prompting?'
  ];

  // Fetch conversations list
  const fetchConversations = async () => {
    try {
      const res = await api.get('/chat/conversations');
      setConversations(res.data);
    } catch (err) {
      console.error('Failed to load conversations:', err);
    }
  };

  useEffect(() => {
    fetchConversations();
  }, []);

  // Fetch messages when currentConversationId changes
  useEffect(() => {
    const loadConversation = async () => {
      if (!currentConversationId) {
        setMessages([]);
        return;
      }
      try {
        const res = await api.get(`/chat/conversations/${currentConversationId}`);
        setMessages(res.data.messages || []);
      } catch (err) {
        console.error('Failed to load conversation messages:', err);
      }
    };
    loadConversation();
  }, [currentConversationId]);

  // Handle URL pre-fill if topic query param provided
  useEffect(() => {
    if (initialTopic && messages.length === 0) {
      setInputText(`Can you explain ${initialTopic} and show me a practical prompt engineering example?`);
    }
  }, [initialTopic]);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = async (textToSend = null) => {
    const content = textToSend || inputText;
    if (!content.trim() || isTyping) return;

    setInputText('');

    // Optimistically append user message
    const tempUserMsg = {
      id: Date.now(),
      role: 'user',
      content: content.trim(),
      created_at: new Date().toISOString()
    };
    setMessages((prev) => [...prev, tempUserMsg]);
    setIsTyping(true);

    try {
      const res = await api.post('/chat', {
        conversation_id: currentConversationId,
        message: content.trim(),
        topic_context: initialTopic || null
      });

      if (!currentConversationId) {
        setCurrentConversationId(res.data.conversation_id);
        fetchConversations();
      }

      setMessages((prev) => {
        // Replace temp message with server version and append assistant
        const withoutTemp = prev.filter((m) => m.id !== tempUserMsg.id);
        return [...withoutTemp, res.data.user_message, res.data.assistant_message];
      });
    } catch (err) {
      console.error('Failed to send message:', err);
      // Append fallback error message
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 1,
          role: 'assistant',
          content: 'I encountered an issue processing your request. Please check your backend connection or try again.',
          created_at: new Date().toISOString()
        }
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleNewChat = () => {
    setCurrentConversationId(null);
    setMessages([]);
    setInputText('');
    inputRef.current?.focus();
  };

  const handleDeleteConversation = async (convId, e) => {
    e.stopPropagation();
    try {
      await api.delete(`/chat/conversations/${convId}`);
      if (currentConversationId === convId) {
        handleNewChat();
      }
      fetchConversations();
    } catch (err) {
      console.error('Failed to delete conversation:', err);
    }
  };

  const handleCopyMessage = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleRegenerate = () => {
    const lastUserMsg = [...messages].reverse().find((m) => m.role === 'user');
    if (lastUserMsg) {
      // Remove last assistant message
      setMessages((prev) => prev.slice(0, prev.length - 1));
      handleSendMessage(lastUserMsg.content);
    }
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] rounded-3xl overflow-hidden border border-slate-800 glass-card">
      {/* Chat History Sidebar */}
      <div
        className={`${
          sidebarOpen ? 'block' : 'hidden'
        } md:block w-72 shrink-0 bg-slate-950/70 border-r border-slate-800 flex flex-col`}
      >
        <div className="p-4 border-b border-slate-800">
          <button
            onClick={handleNewChat}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs shadow-md shadow-brand-600/20 transition"
          >
            <Plus className="w-4 h-4" />
            <span>New Chat</span>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Recent Conversations
          </div>
          {conversations.map((c) => (
            <div
              key={c.id}
              onClick={() => setCurrentConversationId(c.id)}
              className={`group flex items-center justify-between px-3 py-2.5 rounded-xl text-xs cursor-pointer transition ${
                currentConversationId === c.id
                  ? 'bg-slate-800 text-white font-medium border border-slate-700/80'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2 truncate">
                <MessageSquare className="w-3.5 h-3.5 text-brand-400 shrink-0" />
                <span className="truncate">{c.title}</span>
              </div>
              <button
                onClick={(e) => handleDeleteConversation(c.id, e)}
                className="opacity-0 group-hover:opacity-100 p-1 hover:text-rose-400 transition"
                title="Delete chat"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}

          {conversations.length === 0 && (
            <div className="text-center py-8 text-xs text-slate-400">
              No saved conversations.
            </div>
          )}
        </div>
      </div>

      {/* Main Conversation Area */}
      <div className="flex-1 flex flex-col bg-slate-900/40">
        {/* Top Chat Bar */}
        <div className="h-14 px-6 border-b border-slate-800/80 flex items-center justify-between text-xs bg-slate-950/40">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <MessageSquare className="w-4 h-4" />
            </button>
            <div className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-semibold text-white">PromptMaster AI Assistant</span>
            <Badge color="blue" className="hidden sm:inline-flex">
              Educational Tutor
            </Badge>
          </div>

          <div className="flex items-center gap-2">
            {messages.length > 0 && (
              <>
                <button
                  onClick={handleRegenerate}
                  disabled={isTyping}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                  title="Regenerate last response"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Regenerate</span>
                </button>
                <button
                  onClick={handleNewChat}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition"
                  title="Clear conversation"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Clear</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {messages.length === 0 ? (
            <div className="max-w-2xl mx-auto py-12 text-center space-y-6">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-500 flex items-center justify-center text-white mx-auto shadow-xl shadow-brand-500/20">
                <Sparkles className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-white">What would you like to master today?</h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  Ask me any question about prompt design, LLM tokenomics, zero-shot vs few-shot paradigms, or safety guardrails.
                </p>
              </div>

              {/* Suggestions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left pt-4">
                {suggestedPrompts.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(s)}
                    className="p-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-brand-500/40 text-xs text-slate-200 transition text-left flex items-center justify-between group"
                  >
                    <span>{s}</span>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-brand-400 shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((m) => {
              const isUser = m.role === 'user';
              return (
                <div
                  key={m.id}
                  className={`flex gap-3 max-w-3xl ${isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
                >
                  {/* Avatar */}
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      isUser
                        ? 'bg-brand-600 text-white'
                        : 'bg-gradient-to-tr from-indigo-600 to-brand-500 text-white shadow-md shadow-brand-500/20'
                    }`}
                  >
                    {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>

                  {/* Message Bubble */}
                  <div className="space-y-1.5 max-w-[85%] sm:max-w-[80%]">
                    <div
                      className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                        isUser
                          ? 'bg-brand-600 text-white rounded-tr-none'
                          : 'glass-card border border-slate-800 text-slate-200 rounded-tl-none space-y-3'
                      }`}
                    >
                      <div className="whitespace-pre-wrap">{m.content}</div>
                    </div>

                    {/* Metadata & Actions */}
                    <div className="flex items-center gap-2 px-1 text-[10px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      {!isUser && (
                        <button
                          onClick={() => handleCopyMessage(m.content, m.id)}
                          className="hover:text-white transition flex items-center gap-1"
                        >
                          {copiedId === m.id ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}

          {isTyping && (
            <div className="flex gap-3 max-w-3xl mr-auto">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-brand-500 text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-4 rounded-2xl glass-card border border-slate-800 text-slate-300 rounded-tl-none flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-brand-400 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-brand-400 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-brand-400 animate-bounce [animation-delay:0.4s]" />
                <span className="text-xs text-slate-400 ml-1">PromptMaster AI is formulating response...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Chat Input Box */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2 bg-slate-900 border border-slate-700/80 rounded-2xl p-1.5 focus-within:border-brand-500 transition"
          >
            <textarea
              ref={inputRef}
              rows="1"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="Ask PromptMaster anything about prompting or LLMs... (Press Enter to send)"
              className="flex-1 bg-transparent border-none text-xs sm:text-sm text-white placeholder-slate-400 px-3 py-2 resize-none focus:outline-none max-h-32"
            />

            <button
              type="submit"
              disabled={!inputText.trim() || isTyping}
              className="p-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 disabled:opacity-40 text-white transition shadow-md shadow-brand-600/20"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
          <div className="text-[10px] text-slate-400 text-center mt-2">
            PromptMaster AI teaches prompt engineering principles. Check high-stakes answers with official documentation.
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
