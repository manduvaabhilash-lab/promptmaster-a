import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  MessageSquare,
  Clock,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Sparkles,
  Layers,
  Cpu,
  ShieldCheck,
  AlertTriangle,
  Lightbulb,
  Award
} from 'lucide-react';
import api from '../api/client';
import LoadingSpinner from '../components/LoadingSpinner';
import CodeBlock from '../components/CodeBlock';
import Badge from '../components/Badge';

export const TopicDetailPage = () => {
  const { topicId } = useParams();
  const navigate = useNavigate();

  const [topic, setTopic] = useState(null);
  const [allTopics, setAllTopics] = useState([]);
  const [loading, setLoading] = useState(true);

  // Quiz interactive state
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  useEffect(() => {
    const fetchTopicData = async () => {
      setLoading(true);
      try {
        const [topicRes, allRes] = await Promise.all([
          api.get(`/topics/${topicId}`),
          api.get('/topics'),
        ]);
        setTopic(topicRes.data);
        setAllTopics(allRes.data);
        // Reset quiz state when switching topics
        setSelectedAnswers({});
        setQuizSubmitted(false);
        setQuizScore(0);
      } catch (err) {
        console.error('Error fetching topic:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchTopicData();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [topicId]);

  if (loading) {
    return <LoadingSpinner text="Loading topic deep dive..." size="lg" />;
  }

  if (!topic) {
    return (
      <div className="text-center py-20 space-y-4">
        <h2 className="text-2xl font-bold text-white">Topic Not Found</h2>
        <p className="text-slate-400">The requested learning module does not exist.</p>
        <Link to="/learn" className="inline-flex items-center gap-2 text-brand-400 font-semibold">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Topics</span>
        </Link>
      </div>
    );
  }

  // Determine previous and next topics
  const currentIndex = allTopics.findIndex((t) => t.id === topic.id);
  const prevTopic = currentIndex > 0 ? allTopics[currentIndex - 1] : null;
  const nextTopic = currentIndex < allTopics.length - 1 ? allTopics[currentIndex + 1] : null;

  const handleSelectOption = (questionId, optionIndex) => {
    if (quizSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionIndex }));
  };

  const handleSubmitQuiz = async () => {
    let correct = 0;
    const miniQuiz = topic.mini_quiz || [];
    const answersPayload = [];

    miniQuiz.forEach((q) => {
      const selected = selectedAnswers[q.id];
      if (selected !== undefined) {
        answersPayload.push({ question_id: q.id, selected_option: selected });
        if (selected === q.correct_option) {
          correct++;
        }
      }
    });

    setQuizScore(correct);
    setQuizSubmitted(true);

    // Record submission to backend
    try {
      await api.post('/quiz/submit', {
        topic: topic.slug,
        answers: answersPayload,
      });
    } catch (e) {
      console.error('Failed to log quiz attempt:', e);
    }
  };

  return (
    <div className="space-y-12 max-w-5xl mx-auto pb-16">
      {/* Breadcrumb & Navigation Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <Link
            to="/learn"
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 transition"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Curriculum</span>
          </Link>
          <span className="text-slate-600">/</span>
          <span className="text-xs font-mono text-brand-400">Module 0{topic.number}</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(`/chat?topic=${encodeURIComponent(topic.title)}`)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 transition"
          >
            <MessageSquare className="w-3.5 h-3.5 text-brand-400" />
            <span>Ask AI about this topic</span>
          </button>
        </div>
      </div>

      {/* Hero Header */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Badge color="blue">{topic.badge}</Badge>
          <span className="text-xs text-slate-400 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {topic.reading_time}
          </span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
          {topic.title}
        </h1>
        <p className="text-lg text-brand-300 font-medium">
          {topic.subtitle}
        </p>

        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-slate-200 leading-relaxed text-sm">
          {topic.overview}
        </div>
      </section>

      {/* Visual Concept Cards */}
      {topic.visual_cards && topic.visual_cards.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-brand-400" />
            <span>Key Architectural Mechanisms</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {topic.visual_cards.map((card, i) => (
              <div
                key={i}
                className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="w-9 h-9 rounded-xl bg-brand-500/20 text-brand-300 flex items-center justify-center font-bold text-sm mb-3">
                    0{i + 1}
                  </div>
                  <h3 className="text-base font-bold text-white mb-1">{card.title}</h3>
                  <div className="text-xs text-brand-400 font-medium mb-2">{card.subtitle}</div>
                  <p className="text-xs text-slate-300 leading-relaxed">{card.content}</p>
                </div>
                <div className="text-[11px] font-mono text-slate-400 bg-slate-950/70 p-2 rounded-lg border border-slate-800/80">
                  {card.highlight}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* In-Depth Explanation */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-400" />
          <span>Technical Deep Dive</span>
        </h2>
        <div className="glass-card rounded-2xl p-6 sm:p-8 border border-slate-800 text-slate-300 text-sm leading-relaxed space-y-4 whitespace-pre-line">
          {topic.explanation}
        </div>
      </section>

      {/* Key Concepts Grid */}
      {topic.key_concepts && topic.key_concepts.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-purple-400" />
            <span>Fundamental Terminology</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {topic.key_concepts.map((concept, idx) => (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5"
              >
                <div className="text-sm font-bold text-white flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-brand-400" />
                  <span>{concept.term}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pl-4">
                  {concept.definition}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Concrete Prompt Examples & Comparisons */}
      {topic.examples && topic.examples.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-amber-400" />
            <span>Practical Examples & Analysis</span>
          </h2>
          {topic.examples.map((ex, idx) => (
            <div key={idx} className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white">{ex.title}</h3>
                <Badge color="amber">{ex.type}</Badge>
              </div>

              {ex.bad_prompt && (
                <div className="space-y-1">
                  <div className="text-xs font-semibold text-rose-400">❌ Naive / Suboptimal Approach:</div>
                  <CodeBlock code={ex.bad_prompt} language="prompt" title="Naive Prompt" />
                </div>
              )}

              {ex.good_prompt && (
                <div className="space-y-1">
                  <div className="text-xs font-semibold text-emerald-400">✅ Engineered Production Approach:</div>
                  <CodeBlock code={ex.good_prompt} language="prompt" title="Engineered Prompt" />
                </div>
              )}

              <div className="p-3.5 rounded-xl bg-brand-950/20 border border-brand-900/40 text-xs text-brand-200">
                <span className="font-semibold text-brand-300">Why this works: </span>
                {ex.explanation}
              </div>
            </div>
          ))}
        </section>
      )}

      {/* Code Prompt Implementation Snippets */}
      {topic.code_prompt_examples && topic.code_prompt_examples.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-emerald-400" />
            <span>Implementation Patterns</span>
          </h2>
          {topic.code_prompt_examples.map((item, idx) => (
            <CodeBlock
              key={idx}
              code={item.code}
              language={item.language}
              title={item.title}
            />
          ))}
        </section>
      )}

      {/* Common Mistakes vs Best Practices Side-by-Side */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-cyan-400" />
          <span>Mistakes vs Best Practices</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Common Mistakes */}
          <div className="space-y-3 p-5 rounded-2xl bg-rose-950/20 border border-rose-900/30">
            <h3 className="text-sm font-bold text-rose-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <span>Common Pitfalls to Avoid</span>
            </h3>
            <div className="space-y-3">
              {topic.common_mistakes?.map((m, idx) => (
                <div key={idx} className="text-xs space-y-1 border-b border-rose-900/20 pb-2.5 last:border-none">
                  <div className="font-semibold text-rose-200">{m.mistake}</div>
                  <div className="text-slate-400">Cause: {m.why}</div>
                  <div className="text-emerald-300">Correction: {m.fix}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Best Practices */}
          <div className="space-y-3 p-5 rounded-2xl bg-emerald-950/20 border border-emerald-900/30">
            <h3 className="text-sm font-bold text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Engineering Best Practices</span>
            </h3>
            <ul className="space-y-2.5">
              {topic.best_practices?.map((bp, idx) => (
                <li key={idx} className="text-xs text-slate-200 flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">•</span>
                  <span>{bp}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Advantages and Limitations */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2">
          <h3 className="text-sm font-bold text-brand-300">Strategic Advantages</h3>
          <ul className="space-y-2 text-xs text-slate-300">
            {topic.advantages?.map((adv, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-brand-400 font-bold">✔</span>
                <span>{adv}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2">
          <h3 className="text-sm font-bold text-amber-300">Constraints & Limitations</h3>
          <ul className="space-y-2 text-xs text-slate-300">
            {topic.limitations?.map((lim, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">⚠</span>
                <span>{lim}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Interactive Mini Quiz */}
      {topic.mini_quiz && topic.mini_quiz.length > 0 && (
        <section className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400" />
                <span>Knowledge Check: Mini Quiz</span>
              </h2>
              <p className="text-xs text-slate-400">
                Test your comprehension of this module's core mechanisms.
              </p>
            </div>
            {quizSubmitted && (
              <Badge color={quizScore === topic.mini_quiz.length ? 'emerald' : 'amber'}>
                Score: {quizScore} / {topic.mini_quiz.length}
              </Badge>
            )}
          </div>

          <div className="space-y-6">
            {topic.mini_quiz.map((q, qIndex) => {
              const selected = selectedAnswers[q.id];
              return (
                <div key={q.id} className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
                  <p className="text-sm font-bold text-white">
                    {qIndex + 1}. {q.question}
                  </p>

                  <div className="space-y-2">
                    {q.options.map((opt, optIndex) => {
                      const isSelected = selected === optIndex;
                      const isCorrect = q.correct_option === optIndex;
                      let btnStyle = 'border-slate-800 bg-slate-950/60 text-slate-300 hover:border-slate-700';

                      if (isSelected) {
                        btnStyle = 'border-brand-500 bg-brand-500/10 text-white font-medium';
                      }

                      if (quizSubmitted) {
                        if (isCorrect) {
                          btnStyle = 'border-emerald-500 bg-emerald-500/15 text-emerald-200 font-medium';
                        } else if (isSelected && !isCorrect) {
                          btnStyle = 'border-rose-500 bg-rose-500/15 text-rose-200 font-medium';
                        }
                      }

                      return (
                        <button
                          key={optIndex}
                          onClick={() => handleSelectOption(q.id, optIndex)}
                          className={`w-full text-left p-3 rounded-xl border text-xs transition flex items-center justify-between ${btnStyle}`}
                        >
                          <span>{opt}</span>
                          {quizSubmitted && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                          {quizSubmitted && isSelected && !isCorrect && <XCircle className="w-4 h-4 text-rose-400 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>

                  {quizSubmitted && (
                    <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-xs text-slate-300 leading-relaxed">
                      <span className="font-semibold text-brand-400">Explanation: </span>
                      {q.explanation}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-2">
            {!quizSubmitted ? (
              <button
                onClick={handleSubmitQuiz}
                disabled={Object.keys(selectedAnswers).length === 0}
                className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 disabled:opacity-50 text-white font-semibold text-xs transition shadow-md shadow-brand-600/20"
              >
                Submit Answers
              </button>
            ) : (
              <button
                onClick={() => {
                  setQuizSubmitted(false);
                  setSelectedAnswers({});
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition"
              >
                Retake Mini Quiz
              </button>
            )}
          </div>
        </section>
      )}

      {/* Bottom Navigation: Prev / Next Topic */}
      <div className="pt-8 border-t border-slate-800 flex items-center justify-between gap-4">
        {prevTopic ? (
          <Link
            to={`/learn/${prevTopic.id}`}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-300 hover:text-white transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Previous: {prevTopic.title}</span>
          </Link>
        ) : <div />}

        {nextTopic ? (
          <Link
            to={`/learn/${nextTopic.id}`}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-xs font-semibold text-white shadow-lg shadow-brand-600/20 transition"
          >
            <span>Next: {nextTopic.title}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        ) : (
          <Link
            to="/quiz"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition"
          >
            <span>Complete Master Quiz</span>
            <Award className="w-4 h-4" />
          </Link>
        )}
      </div>
    </div>
  );
};

export default TopicDetailPage;
