import React, { useState, useEffect } from 'react';
import {
  Wand2,
  Copy,
  Check,
  Bookmark,
  Sparkles,
  ArrowRight,
  Sliders,
  Trash2,
  MessageSquare,
  HelpCircle,
  FolderOpen
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import api from '../api/client';
import LoadingSpinner from '../components/LoadingSpinner';
import Badge from '../components/Badge';
import Modal from '../components/Modal';

export const PromptGeneratorPage = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    task: '',
    goal: '',
    context: '',
    role: '',
    audience: '',
    constraints: '',
    desired_format: '',
    examples: '',
  });

  const [generating, setGenerating] = useState(false);
  const [improving, setImproving] = useState(false);
  const [output, setOutput] = useState(null);
  const [copied, setCopied] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Saved Prompts Modal
  const [savedModalOpen, setSavedModalOpen] = useState(false);
  const [savedPrompts, setSavedPrompts] = useState([]);
  const [promptTitle, setPromptTitle] = useState('');

  const presets = [
    {
      name: 'Technical Explainer',
      data: {
        task: 'Explain the difference between Monolithic and Microservice software architectures',
        role: 'You are a Principal Software Architect',
        audience: 'Junior backend engineers',
        goal: 'Provide a clear mental model of distributed trade-offs',
        constraints: 'Include 3 pros and 3 cons for each. Keep under 400 words.',
        desired_format: 'Markdown with comparison table',
      },
    },
    {
      name: 'JSON Entity Extractor',
      data: {
        task: 'Extract key business terms from contract agreements',
        role: 'You are a legal data parser',
        audience: 'Automated CRM integration',
        goal: 'Produce clean machine-readable entities without conversation',
        constraints: 'Return ONLY valid JSON. If any field is missing, set to null.',
        desired_format: 'JSON Schema: { effective_date, party_a, party_b, liability_cap, governing_law }',
      },
    },
    {
      name: 'Executive Briefing',
      data: {
        task: 'Synthesize quarterly product metrics and customer churn trends',
        role: 'You are a Chief Product Officer chief of staff',
        audience: 'Board of Directors',
        goal: 'Highlight strategic revenue risks and top 3 mitigation initiatives',
        constraints: 'Strictly 3 bullet points per section. High-signal, zero fluff.',
        desired_format: 'Executive summary memo',
      },
    },
  ];

  const fetchSavedPrompts = async () => {
    try {
      const res = await api.get('/prompt/saved');
      setSavedPrompts(res.data);
    } catch (err) {
      console.error('Failed to fetch saved prompts:', err);
    }
  };

  useEffect(() => {
    fetchSavedPrompts();
  }, []);

  const handleGenerate = async () => {
    if (!formData.task.trim()) return;
    setGenerating(true);
    try {
      const res = await api.post('/prompt/generate', formData);
      setOutput(res.data);
      setPromptTitle(formData.task.slice(0, 35));
    } catch (err) {
      console.error('Failed to generate prompt:', err);
    } finally {
      setGenerating(false);
    }
  };

  const handleImprove = async () => {
    if (!output?.optimized_prompt) return;
    setImproving(true);
    try {
      const res = await api.post('/prompt/improve', {
        prompt: output.optimized_prompt,
        target_focus: 'strict structural constraints and zero hallucination boundaries',
      });
      setOutput((prev) => ({
        ...prev,
        optimized_prompt: res.data.improved_prompt,
        explanation: res.data.rationale,
      }));
    } catch (err) {
      console.error('Failed to improve prompt:', err);
    } finally {
      setImproving(false);
    }
  };

  const handleSave = async () => {
    if (!output?.optimized_prompt) return;
    try {
      await api.post('/prompt/save', {
        title: promptTitle.trim() || formData.task.slice(0, 35) || 'Engineered Prompt',
        content: output.optimized_prompt,
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
      fetchSavedPrompts();
    } catch (err) {
      console.error('Failed to save prompt:', err);
    }
  };

  const handleDeleteSaved = async (id) => {
    try {
      await api.delete(`/prompt/saved/${id}`);
      fetchSavedPrompts();
    } catch (err) {
      console.error('Failed to delete prompt:', err);
    }
  };

  const handleCopy = () => {
    if (!output?.optimized_prompt) return;
    navigator.clipboard.writeText(output.optimized_prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const applyPreset = (preset) => {
    setFormData((prev) => ({ ...prev, ...preset.data }));
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs font-semibold mb-2">
            <Wand2 className="w-3.5 h-3.5" />
            <span>Structured Prompt Synthesis</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">Production Prompt Generator</h1>
          <p className="text-sm text-slate-400 max-w-xl">
            Deconstruct tasks into the 4-tier Role-Task-Constraint-Format paradigm for predictable, high-precision completions.
          </p>
        </div>

        <button
          onClick={() => setSavedModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 border border-slate-800 hover:border-slate-700 transition"
        >
          <FolderOpen className="w-4 h-4 text-purple-400" />
          <span>My Saved Prompts ({savedPrompts.length})</span>
        </button>
      </div>

      {/* Preset Quick Fill */}
      <div className="flex items-center gap-2 flex-wrap text-xs">
        <span className="text-slate-400 font-medium">Quick Presets:</span>
        {presets.map((p) => (
          <button
            key={p.name}
            onClick={() => applyPreset(p)}
            className="px-3 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition"
          >
            {p.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Form Inputs (Left) */}
        <div className="lg:col-span-6 glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-brand-400" />
            <span>Prompt Configuration Parameters</span>
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Primary Task <span className="text-rose-400">*</span>
              </label>
              <textarea
                rows="2"
                value={formData.task}
                onChange={(e) => setFormData({ ...formData, task: e.target.value })}
                placeholder="What must the AI execute? (e.g. Audit this Python script for memory leaks)"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Role / Persona</label>
                <input
                  type="text"
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  placeholder="e.g. Senior Security Auditor"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Target Audience</label>
                <input
                  type="text"
                  value={formData.audience}
                  onChange={(e) => setFormData({ ...formData, audience: e.target.value })}
                  placeholder="e.g. CTO & Security Team"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Context & Background</label>
              <textarea
                rows="2"
                value={formData.context}
                onChange={(e) => setFormData({ ...formData, context: e.target.value })}
                placeholder="Background information, domain rules, or reference data sources..."
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Constraints & Negative Rules (One per line)
              </label>
              <textarea
                rows="2"
                value={formData.constraints}
                onChange={(e) => setFormData({ ...formData, constraints: e.target.value })}
                placeholder="Limit to 3 paragraphs&#10;Do not invent external packages&#10;Include time complexity"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Desired Format</label>
                <input
                  type="text"
                  value={formData.desired_format}
                  onChange={(e) => setFormData({ ...formData, desired_format: e.target.value })}
                  placeholder="e.g. Markdown table, JSON, Bullet points"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Strategic Goal</label>
                <input
                  type="text"
                  value={formData.goal}
                  onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
                  placeholder="e.g. Prevent production downtime"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950/80 border border-slate-700/80 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-brand-500"
                />
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={!formData.task.trim() || generating}
              className="w-full py-3 rounded-xl bg-brand-600 hover:bg-brand-500 disabled:opacity-40 text-white font-semibold text-xs transition shadow-lg shadow-brand-600/20 flex items-center justify-center gap-2 mt-4"
            >
              {generating ? (
                <span>Synthesizing Optimal Prompt...</span>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Generate Prompt</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Output Pane (Right) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="glass-card rounded-2xl p-6 border border-slate-800 flex flex-col justify-between h-full space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Optimized Output
                </span>
                {output && (
                  <Badge color="emerald">Structured Specification</Badge>
                )}
              </div>

              {output ? (
                <div className="space-y-4">
                  {/* Generated Prompt Code Container */}
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-200 whitespace-pre-wrap max-h-96 overflow-y-auto leading-relaxed selection:bg-brand-500/40">
                    {output.optimized_prompt}
                  </div>

                  {output.explanation && (
                    <div className="p-3.5 rounded-xl bg-brand-950/20 border border-brand-900/30 text-xs text-brand-300">
                      <span className="font-semibold text-white">Design Rationale: </span>
                      {output.explanation}
                    </div>
                  )}
                </div>
              ) : (
                <div className="py-24 text-center space-y-3">
                  <div className="w-12 h-12 rounded-xl bg-slate-900 text-slate-500 flex items-center justify-center mx-auto">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-white">Awaiting Inputs</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                    Fill in the parameters on the left or select a quick preset, then click "Generate Prompt" to formulate an engineered template.
                  </p>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            {output && (
              <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 font-medium">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Prompt</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleImprove}
                    disabled={improving}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-amber-300 hover:text-amber-200 transition"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{improving ? 'Improving...' : 'Improve Prompt'}</span>
                  </button>

                  <button
                    onClick={handleSave}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-purple-300 hover:text-purple-200 transition"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>{savedSuccess ? 'Saved!' : 'Save Prompt'}</span>
                  </button>
                </div>

                <button
                  onClick={() => navigate('/chat')}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-xs font-semibold text-white transition shadow-md shadow-brand-600/20"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Test in AI Chat</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Saved Prompts Modal */}
      <Modal
        isOpen={savedModalOpen}
        onClose={() => setSavedModalOpen(false)}
        title="Saved Prompt Templates"
        maxWidth="max-w-2xl"
      >
        <div className="space-y-4">
          {savedPrompts.map((p) => (
            <div
              key={p.id}
              className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2"
            >
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white">{p.title}</h4>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(p.content);
                      alert('Copied saved prompt to clipboard!');
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                    title="Copy"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteSaved(p.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="p-3 rounded-lg bg-slate-950 font-mono text-xs text-slate-300 max-h-32 overflow-y-auto whitespace-pre-wrap">
                {p.content}
              </div>
              <div className="text-[10px] text-slate-400">
                Created: {new Date(p.created_at).toLocaleDateString()}
              </div>
            </div>
          ))}

          {savedPrompts.length === 0 && (
            <div className="text-center py-12 text-slate-400 text-xs">
              No prompts saved yet. Generate an optimized prompt and click "Save Prompt".
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};

export default PromptGeneratorPage;
