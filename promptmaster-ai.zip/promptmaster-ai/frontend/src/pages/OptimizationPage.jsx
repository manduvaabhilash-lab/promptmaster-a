import React, { useState } from 'react';
import { Sliders, Sparkles, Database, CheckCircle2, ArrowRight, Activity, GitFork, AlertTriangle } from 'lucide-react';
import Badge from '../components/Badge';

export const OptimizationPage = () => {
  // Interactive hyperparameter simulator state
  const [temperature, setTemperature] = useState(0.2);
  const [topP, setTopP] = useState(0.95);
  const [maxTokens, setMaxTokens] = useState(500);

  // Interpretation of temperature
  const getTempDescription = (temp) => {
    if (temp <= 0.1) return 'Deterministic / Greedy: Identical outputs, best for math, SQL, and strict JSON schemas.';
    if (temp <= 0.5) return 'Low Entropy: Analytical, factual summarization, code generation, and Q&A.';
    if (temp <= 0.8) return 'Balanced: Good balance between creativity and coherence, best for chat avatars and articles.';
    return 'High Entropy: Maximum lexical diversity and brainstorming, but increased risk of incoherence.';
  };

  return (
    <div className="space-y-12 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs font-semibold mb-2">
          <Sliders className="w-3.5 h-3.5" />
          <span>ML Systems Architecture</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">Fine-Tuning & Prompt Optimization</h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Evaluate the technical and economic trade-offs between In-Context Prompt Engineering, Retrieval-Augmented Generation (RAG), and Parameter Fine-Tuning.
        </p>
      </div>

      {/* Comparative Architecture Matrix */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-6">
        <div>
          <h2 className="text-xl font-bold text-white">Prompt Engineering vs Fine-Tuning Matrix</h2>
          <p className="text-xs text-slate-400">
            A practical decision framework for machine learning engineers.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-3 px-4 font-bold uppercase tracking-wider">Dimension</th>
                <th className="py-3 px-4 font-bold text-brand-300 uppercase tracking-wider">
                  Prompt Engineering
                </th>
                <th className="py-3 px-4 font-bold text-emerald-300 uppercase tracking-wider">
                  RAG (Retrieval)
                </th>
                <th className="py-3 px-4 font-bold text-purple-300 uppercase tracking-wider">
                  Fine-Tuning (SFT / LoRA)
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Setup Time</td>
                <td className="py-3 px-4 text-emerald-400">Minutes</td>
                <td className="py-3 px-4 text-emerald-400">Hours to Days</td>
                <td className="py-3 px-4 text-amber-400">Days to Weeks</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Computational Cost</td>
                <td className="py-3 px-4 text-emerald-400">Zero training compute</td>
                <td className="py-3 px-4 text-emerald-400">Vector database indexing</td>
                <td className="py-3 px-4 text-rose-400">Dedicated GPU clusters</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Updating Knowledge</td>
                <td className="py-3 px-4 text-emerald-400">Instant (edit prompt text)</td>
                <td className="py-3 px-4 text-emerald-400">Instant (update document DB)</td>
                <td className="py-3 px-4 text-rose-400">Requires complete retraining</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Best Used For</td>
                <td className="py-3 px-4">Reasoning, general tasks, prototyping</td>
                <td className="py-3 px-4">Dynamic private documents, factual citations</td>
                <td className="py-3 px-4">Strict proprietary syntax, specialized tone, latency savings</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-white">Risk of Forgetting</td>
                <td className="py-3 px-4 text-emerald-400">None</td>
                <td className="py-3 px-4 text-emerald-400">None</td>
                <td className="py-3 px-4 text-amber-400">Catastrophic forgetting of baseline logic</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Hyperparameter Calibration Lab */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-emerald-400" />
              <span>Inference Hyperparameter Calibration</span>
            </h2>
            <p className="text-xs text-slate-400">
              Simulate how sampling hyperparameters alter token probability distributions.
            </p>
          </div>
          <Badge color="emerald">Inference Physics</Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Temperature Slider */}
          <div className="space-y-2 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white">Temperature</span>
              <span className="font-mono text-brand-400 font-bold">{temperature.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="1.5"
              step="0.05"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-full accent-brand-500"
            />
            <div className="text-[11px] text-slate-400 pt-2 leading-relaxed">
              Rescales logits before softmax:
              <span className="block font-mono text-brand-300 mt-1">P(w) ∝ exp(z_i / T)</span>
            </div>
          </div>

          {/* Top-P (Nucleus Sampling) */}
          <div className="space-y-2 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white">Top-P (Nucleus)</span>
              <span className="font-mono text-brand-400 font-bold">{topP.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="1.0"
              step="0.05"
              value={topP}
              onChange={(e) => setTopP(parseFloat(e.target.value))}
              className="w-full accent-brand-500"
            />
            <div className="text-[11px] text-slate-400 pt-2 leading-relaxed">
              Restricts candidate pool to the smallest set whose cumulative probability exceeds P.
            </div>
          </div>

          {/* Max Tokens Slider */}
          <div className="space-y-2 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white">Max Output Tokens</span>
              <span className="font-mono text-brand-400 font-bold">{maxTokens} tokens</span>
            </div>
            <input
              type="range"
              min="50"
              max="2048"
              step="50"
              value={maxTokens}
              onChange={(e) => setMaxTokens(parseInt(e.target.value))}
              className="w-full accent-brand-500"
            />
            <div className="text-[11px] text-slate-400 pt-2 leading-relaxed">
              Hard boundary cutoff on generated completion length. Bounds API cost and latency.
            </div>
          </div>
        </div>

        {/* Dynamic Behavioral Output Summary */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
          <span className="font-bold text-emerald-400">Behavioral Prediction: </span>
          <span>{getTempDescription(temperature)}</span>
        </div>
      </div>

      {/* The 4-Stage Optimization Cycle */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-white">The Production Optimization Lifecycle</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <span className="text-brand-400 font-mono font-bold text-xs">PHASE 01</span>
            <h3 className="text-sm font-bold text-white">Curate Eval Benchmark</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Assemble 50-100 real-world customer queries with human gold-standard answers.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <span className="text-brand-400 font-mono font-bold text-xs">PHASE 02</span>
            <h3 className="text-sm font-bold text-white">Iterate Prompts</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Introduce role conditioning, few-shot demonstrations, and explicit schema constraints.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <span className="text-brand-400 font-mono font-bold text-xs">PHASE 03</span>
            <h3 className="text-sm font-bold text-white">Automate Scoring</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Run automated regression suites using LLM-as-a-judge to measure accuracy across test cases.
            </p>
          </div>

          <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <span className="text-brand-400 font-mono font-bold text-xs">PHASE 04</span>
            <h3 className="text-sm font-bold text-white">Deploy & Monitor</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Log production latency, token costs, and user negative feedback for continuous refinement.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OptimizationPage;
