import React, { useState } from 'react';
import { Compass, Sparkles, CheckCircle2, ArrowRight, Lightbulb, Copy, SplitSquareVertical } from 'lucide-react';
import Badge from '../components/Badge';
import CodeBlock from '../components/CodeBlock';

const STRATEGIES = [
  {
    num: '01',
    title: 'Be Specific & Direct',
    desc: 'Avoid vague, ambiguous prompts. State exact quantities, desired depth, target terminology, and specific objectives.',
    tip: 'Instead of "Write something about Python", use "Write a 3-paragraph tutorial on Python context managers using the `with` keyword."'
  },
  {
    num: '02',
    title: 'Provide Grounding Context',
    desc: 'Give the model the necessary background facts, business logic, or source text so it does not rely on statistical guesswork.',
    tip: 'Always provide documentation or historical logs directly in `<context>` delimiters.'
  },
  {
    num: '03',
    title: 'Assign an Explicit Role',
    desc: 'Set an authoritative persona ("Act as a senior database administrator"). Roles prime domain-specific terminology and appropriate tone.',
    tip: 'Combine the role with the target audience to calibrate complexity.'
  },
  {
    num: '04',
    title: 'Define Boundary Constraints',
    desc: 'Tell the model what NOT to do, maximum token or sentence limits, and what to do when requested facts are absent.',
    tip: 'State fallback rules: "If the author is not mentioned in the text, respond with [AUTHOR UNLISTED]."'
  },
  {
    num: '05',
    title: 'Provide Few-Shot Exemplars',
    desc: 'Show 1 to 3 demonstrations of input -> output pairs. Examples communicate format 10x faster than paragraphs of instructions.',
    tip: 'Include at least one edge case in your few-shot exemplars.'
  },
  {
    num: '06',
    title: 'Specify Output Format',
    desc: 'Explicitly request JSON, Markdown tables, numbered lists, or XML tags. Provide exact schemas when requesting JSON.',
    tip: 'Demand: "Return ONLY raw JSON without markdown fences or conversational preambles."'
  },
  {
    num: '07',
    title: 'Break Complex Tasks into Steps (CoT)',
    desc: 'Encourage intermediate reasoning ("Think step by step"). In multi-step problems, intermediate tokens allow the model to calculate before concluding.',
    tip: 'Use numbered sub-tasks: 1. Decompose premise, 2. Check consistency, 3. Conclude.'
  },
  {
    num: '08',
    title: 'Ask for Verification & Critique',
    desc: 'Command the model to review its own generated draft against quality rubrics before presenting the final answer.',
    tip: 'Self-reflection drastically cuts careless omissions in code synthesis and policy analysis.'
  },
  {
    num: '09',
    title: 'Iterate & Experiment Systematically',
    desc: 'Treat prompts like source code. Change one variable at a time, test across a benchmark of 20-30 diverse inputs, and track accuracy.',
    tip: 'Never judge a prompt based on a single successful completion.'
  },
  {
    num: '10',
    title: 'Use Structured Delimiters',
    desc: 'Enclose instructions, data, and constraints inside distinct semantic tags like `###`, `---`, or `<rules>`, `<input_data>`.',
    tip: 'Delimiters prevent prompt injection and keep attention weights focused cleanly.'
  }
];

const COMPARISON_SHOWCASE = [
  {
    title: 'AI Explanation',
    bad: 'Explain AI.',
    good: 'Explain artificial intelligence to a first-year engineering student using a simple definition, three examples, and a short real-world application.',
    explanation: 'The improved version defines the target audience (first-year engineering student), the exact structural sections (definition + 3 examples + 1 application), and avoids open-ended essay rambling.'
  },
  {
    title: 'Customer Ticket Classification',
    bad: 'Classify this email.',
    good: 'You are a customer triage assistant. Classify the customer email below into [BILLING, TECHNICAL, GENERAL]. Output JSON format with keys: "category", "urgency" (Low/Med/High), and "one_sentence_reason".',
    explanation: 'The engineered prompt provides the role, closed classification categories, exact JSON keys, and asks for a structured reason rather than unstructured text.'
  },
  {
    title: 'Bug Fixing & Security',
    bad: 'Fix this code.',
    good: 'Act as a Senior Application Security Engineer. Audit the following Python function for SQL injection risks. Provide: 1. Explanation of the vulnerability, 2. Secure parameterized rewrite using SQLAlchemy, 3. One unit test demonstrating the fix.',
    explanation: 'Assigns an expert security role, isolates the vulnerability type, demands an enterprise-standard library (SQLAlchemy), and requires unit-test verification.'
  }
];

export const StrategiesPage = () => {
  const [selectedComparison, setSelectedComparison] = useState(0);

  return (
    <div className="space-y-12 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs font-semibold mb-2">
          <Compass className="w-3.5 h-3.5" />
          <span>Core Engineering Methodologies</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">Prompt Engineering Strategies</h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          The 10 foundational strategies used by leading AI engineers to eliminate hallucination, ensure deterministic schemas, and elicit high-order reasoning.
        </p>
      </div>

      {/* Interactive Bad Prompt vs Improved Prompt Showcase */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <SplitSquareVertical className="w-5 h-5 text-brand-400" />
              <h2 className="text-xl font-bold text-white">Interactive Transformation Showcase</h2>
            </div>
            <p className="text-xs text-slate-400">
              See the exact difference between naive intuition and engineered prompting.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {COMPARISON_SHOWCASE.map((item, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedComparison(idx)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition ${
                  selectedComparison === idx
                    ? 'bg-brand-600 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {item.title}
              </button>
            ))}
          </div>
        </div>

        {/* Comparison Diffs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Bad Prompt */}
          <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-900/30 flex flex-col justify-between space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
                  ❌ Naive / Suboptimal Prompt
                </span>
                <Badge color="rose">Unconstrained</Badge>
              </div>
              <div className="p-4 rounded-xl bg-slate-950/80 border border-rose-900/40 font-mono text-sm text-rose-200">
                "{COMPARISON_SHOWCASE[selectedComparison].bad}"
              </div>
            </div>
            <div className="text-xs text-rose-300/80 space-y-1 pt-2">
              <div className="font-semibold">Failure mode:</div>
              <p>Leaves tone, length, persona, and output structure completely to chance.</p>
            </div>
          </div>

          {/* Improved Prompt */}
          <div className="p-5 rounded-2xl bg-emerald-950/20 border border-emerald-900/30 flex flex-col justify-between space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                  ✅ Mastered Engineered Prompt
                </span>
                <Badge color="emerald">Precision Aligned</Badge>
              </div>
              <div className="p-4 rounded-xl bg-slate-950/80 border border-emerald-900/40 font-mono text-xs text-emerald-200 leading-relaxed whitespace-pre-wrap">
                "{COMPARISON_SHOWCASE[selectedComparison].good}"
              </div>
            </div>
            <div className="text-xs text-emerald-300/80 space-y-1 pt-2">
              <div className="font-semibold">Engineering impact:</div>
              <p>{COMPARISON_SHOWCASE[selectedComparison].explanation}</p>
            </div>
          </div>
        </div>
      </div>

      {/* The 10 Strategies Grid */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-white">The 10 Core Prompt Engineering Rules</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {STRATEGIES.map((strat) => (
            <div
              key={strat.num}
              className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3 hover:border-slate-700 transition"
            >
              <div className="flex items-center gap-3">
                <span className="w-8 h-8 rounded-lg bg-brand-500/20 text-brand-300 font-bold font-mono text-xs flex items-center justify-center">
                  {strat.num}
                </span>
                <h3 className="text-base font-bold text-white">{strat.title}</h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed pl-11">
                {strat.desc}
              </p>
              <div className="ml-11 p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] text-brand-300">
                <span className="font-semibold text-white">Actionable Rule: </span>
                {strat.tip}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StrategiesPage;
