import React, { useState } from 'react';
import { ShieldCheck, AlertTriangle, CheckCircle2, SplitSquareVertical, ArrowRight, UserCheck, Eye } from 'lucide-react';
import Badge from '../components/Badge';

export const BiasMitigationPage = () => {
  const [selectedExample, setSelectedExample] = useState(0);

  const biasScenarios = [
    {
      title: 'Hiring & Candidate Evaluation',
      biasedPrompt: 'Review this software engineer resume and determine if the candidate is a strong cultural fit for our fast-paced startup team. Name: John / Maria.',
      biasedRisk: 'Asking for subjective "cultural fit" invites demographic stereotyping, pedigree bias, and subtle gender affinity patterns.',
      debiasedPrompt: `You are an objective technical recruiter. Evaluate the candidate resume strictly against the following 4 job competencies:
1. Python backend architecture (REST/async)
2. Database query optimization (PostgreSQL/SQLAlchemy)
3. CI/CD automation & Docker deployment
4. Code review & technical documentation

Do NOT infer or consider candidate age, gender, geographic origin, or non-technical traits. Provide an integer rating (1-5) per competency based solely on verified project experience in the text.`,
      debiasedImprovement: 'Replaces subjective cultural fit with a 4-point technical competency rubric and explicit negative constraints against demographic inference.'
    },
    {
      title: 'Credit Risk & Loan Qualification',
      biasedPrompt: 'Analyze this borrower profile and explain why their neighborhood or spending habits make them high-risk for loan approval.',
      biasedRisk: 'Confirmation bias in the prompt forces the model to search for negative stereotypes and penalize protected geographic zones (redlining).',
      debiasedPrompt: `Act as a credit risk analyst under Equal Credit Opportunity Act compliance.
Evaluate the applicant's creditworthiness strictly using empirical financial metrics:
- Debt-to-Income (DTI) ratio
- Verifiable annual income
- Documented 24-month repayment history
- Loan-to-Value (LTV) ratio

Maintain complete neutrality. Flag any missing financial documents objectively without drawing speculative inferences.`,
      debiasedImprovement: 'Eliminates leading biased language, anchors assessment to statutory financial ratios, and adheres to non-discrimination standards.'
    }
  ];

  const techniques = [
    {
      title: 'Counterfactual Prompt Testing',
      desc: 'Systematically swap demographic identifiers (names, gender pronouns, ethnicities) while holding qualifications identical to detect model bias disparities.'
    },
    {
      title: 'Explicit Rubric Grounding',
      desc: 'Never ask open-ended questions like "Is this good?". Provide an explicit numeric scoring checklist across objective criteria.'
    },
    {
      title: 'Neutral Non-Leading Phrasing',
      desc: 'Avoid prompts that prime negative or positive conclusions ("Explain why X failed..."). Use balanced inquiries ("Evaluate the outcomes of X...").'
    },
    {
      title: 'Demographic Obfuscation',
      desc: 'Strip candidate names, dates of birth, and identifiable geographic postal codes from prompt context before model evaluation.'
    },
    {
      title: 'Diverse Few-Shot Exemplars',
      desc: 'Ensure few-shot demonstration examples represent diverse demographics, balanced sentiments, and multifaceted problem domains.'
    },
    {
      title: 'Human-in-the-Loop Review',
      desc: 'High-stakes decisions (admissions, hiring, lending, clinical summaries) must mandate a human officer authorization gate.'
    }
  ];

  return (
    <div className="space-y-12 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-semibold mb-2">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Fairness & Responsible AI</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">Bias Mitigation & AI Safety</h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Identify algorithmic and cognitive bias vectors in generative systems and engineer debiased prompts for objective decision support.
        </p>
      </div>

      {/* Sources of Bias Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">Source 01</span>
          <h3 className="text-base font-bold text-white">Pretraining Data Skew</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            LLMs inherit historical societal prejudices, stereotypical associations, and linguistic disparities embedded in web-scale pretraining datasets.
          </p>
        </div>

        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Source 02</span>
          <h3 className="text-base font-bold text-white">Prompt Confirmation Bias</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Prompts that subtly lead the model ("Why is candidate X unsuitable?") cause autoregressive generation to fulfill the user's negative expectation.
          </p>
        </div>

        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2">
          <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Source 03</span>
          <h3 className="text-base font-bold text-white">Representation Gaps</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Under-representation of low-resource languages and localized cultural idioms leads to elevated hallucination and inaccuracy on non-Western contexts.
          </p>
        </div>
      </div>

      {/* Interactive Debiasing Comparison */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <SplitSquareVertical className="w-5 h-5 text-cyan-400" />
              <span>Interactive Prompt Debiasing Showcase</span>
            </h2>
            <p className="text-xs text-slate-400">
              Select an enterprise scenario to observe how objective prompt restructuring prevents bias.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {biasScenarios.map((item, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedExample(idx)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition ${
                  selectedExample === idx
                    ? 'bg-cyan-600 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {item.title}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Biased Prompt */}
          <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
                ❌ Biased / Leading Prompt
              </span>
              <Badge color="rose">High Stereotyping Risk</Badge>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 font-mono text-xs text-rose-200 whitespace-pre-wrap">
              "{biasScenarios[selectedExample].biasedPrompt}"
            </div>
            <div className="text-xs text-rose-300/80 pt-1">
              <span className="font-semibold text-rose-300">Failure Risk: </span>
              {biasScenarios[selectedExample].biasedRisk}
            </div>
          </div>

          {/* Debiased Prompt */}
          <div className="p-5 rounded-2xl bg-cyan-950/20 border border-cyan-900/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                ✅ Engineered Debiased Prompt
              </span>
              <Badge color="blue">Objective Rubric</Badge>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 font-mono text-xs text-cyan-200 whitespace-pre-wrap leading-relaxed">
              "{biasScenarios[selectedExample].debiasedPrompt}"
            </div>
            <div className="text-xs text-cyan-300/80 pt-1">
              <span className="font-semibold text-cyan-300">Debiasing Strategy: </span>
              {biasScenarios[selectedExample].debiasedImprovement}
            </div>
          </div>
        </div>
      </div>

      {/* 6 Debiasing Techniques */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-white">6 Practical Debiasing Techniques</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {techniques.map((t, idx) => (
            <div
              key={idx}
              className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2 hover:border-slate-700 transition"
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-white">{t.title}</h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{t.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BiasMitigationPage;
