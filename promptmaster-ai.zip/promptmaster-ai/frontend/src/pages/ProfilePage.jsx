import React, { useState, useEffect } from 'react';
import { User, Award, BookOpen, FlaskConical, Bookmark, Trash2, Copy, Sparkles, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import LoadingSpinner from '../components/LoadingSpinner';
import Badge from '../components/Badge';
import { useAuth } from '../context/AuthContext';

export const ProfilePage = () => {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState(null);
  const [savedPrompts, setSavedPrompts] = useState([]);
  const [quizHistory, setQuizHistory] = useState([]);
  const [practiceHistory, setPracticeHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState(null);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [pRes, sRes, qRes, prRes] = await Promise.all([
          api.get('/profile'),
          api.get('/prompt/saved'),
          api.get('/quiz/history'),
          api.get('/practice/history'),
        ]);
        setProfileData(pRes.data);
        setSavedPrompts(sRes.data);
        setQuizHistory(qRes.data);
        setPracticeHistory(prRes.data);
      } catch (err) {
        console.error('Error loading profile:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  const handleDeleteSaved = async (id) => {
    try {
      await api.delete(`/prompt/saved/${id}`);
      setSavedPrompts((prev) => prev.filter((p) => p.id !== id));
    } catch (err) {
      console.error('Failed to delete saved prompt:', err);
    }
  };

  const handleCopyPrompt = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (loading) {
    return <LoadingSpinner text="Loading student profile..." size="lg" />;
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-16">
      {/* Profile Header Card */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 flex flex-col sm:flex-row items-center gap-6">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-500 text-white flex items-center justify-center font-bold text-2xl shadow-xl shadow-brand-500/20">
          {profileData?.name ? profileData.name[0].toUpperCase() : 'U'}
        </div>

        <div className="space-y-2 text-center sm:text-left flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <h1 className="text-2xl font-bold text-white">{profileData?.name || 'Guest Student'}</h1>
            {profileData?.is_guest && <Badge color="slate">Guest Mode</Badge>}
          </div>
          <p className="text-xs text-slate-400 font-mono">{profileData?.email}</p>
          <p className="text-xs text-slate-300">{profileData?.bio}</p>

          {/* Badges Earned */}
          <div className="flex flex-wrap items-center gap-2 pt-2">
            {profileData?.badges?.map((badge, idx) => (
              <Badge key={idx} color="indigo" className="text-xs">
                <Award className="w-3 h-3 text-indigo-400" />
                <span>{badge}</span>
              </Badge>
            ))}
          </div>
        </div>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="glass-card rounded-2xl p-4 border border-slate-800 text-center">
          <div className="text-2xl font-bold text-white">{quizHistory.length}</div>
          <div className="text-xs text-slate-400">Quizzes Taken</div>
        </div>
        <div className="glass-card rounded-2xl p-4 border border-slate-800 text-center">
          <div className="text-2xl font-bold text-emerald-400">{practiceHistory.length}</div>
          <div className="text-xs text-slate-400">Prompts Evaluated</div>
        </div>
        <div className="glass-card rounded-2xl p-4 border border-slate-800 text-center">
          <div className="text-2xl font-bold text-purple-400">{savedPrompts.length}</div>
          <div className="text-xs text-slate-400">Saved Templates</div>
        </div>
        <div className="glass-card rounded-2xl p-4 border border-slate-800 text-center">
          <div className="text-2xl font-bold text-brand-400">
            {quizHistory.length > 0
              ? Math.round(
                  quizHistory.reduce((acc, q) => acc + q.percentage, 0) / quizHistory.length
                )
              : 0}
            %
          </div>
          <div className="text-xs text-slate-400">Avg Quiz Grade</div>
        </div>
      </div>

      {/* Saved Prompts Section */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Bookmark className="w-4 h-4 text-purple-400" />
            <span>Saved Production Prompts</span>
          </h3>
          <Link
            to="/prompt-generator"
            className="text-xs text-brand-400 hover:text-brand-300 font-semibold"
          >
            + Generate More
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {savedPrompts.map((p) => (
            <div
              key={p.id}
              className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-xs font-bold text-white truncate">{p.title}</h4>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleCopyPrompt(p.content, p.id)}
                      className="p-1 rounded text-slate-400 hover:text-white"
                      title="Copy"
                    >
                      {copiedId === p.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <button
                      onClick={() => handleDeleteSaved(p.id)}
                      className="p-1 rounded text-slate-400 hover:text-rose-400"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-950 font-mono text-[11px] text-slate-300 max-h-24 overflow-y-auto whitespace-pre-wrap">
                  {p.content}
                </div>
              </div>
              <div className="text-[10px] text-slate-500 pt-2 border-t border-slate-800/80">
                Saved {new Date(p.created_at).toLocaleDateString()}
              </div>
            </div>
          ))}

          {savedPrompts.length === 0 && (
            <div className="col-span-full text-center py-8 text-xs text-slate-400">
              No saved prompts yet. Use the Prompt Generator to design and save production templates.
            </div>
          )}
        </div>
      </div>

      {/* Recent Activity: Quizzes & Practice Attempts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Quiz Attempts */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span>Recent Quiz Scores</span>
          </h3>
          <div className="space-y-2">
            {quizHistory.slice(0, 5).map((q) => (
              <div
                key={q.id}
                className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs"
              >
                <span className="font-semibold text-white uppercase">{q.topic}</span>
                <Badge color={q.percentage >= 70 ? 'emerald' : 'amber'}>
                  {q.percentage}%
                </Badge>
              </div>
            ))}
            {quizHistory.length === 0 && (
              <p className="text-xs text-slate-400 py-4 text-center">No quizzes taken yet.</p>
            )}
          </div>
        </div>

        {/* Practice Attempts */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <FlaskConical className="w-4 h-4 text-emerald-400" />
            <span>Recent Prompt Lab Scores</span>
          </h3>
          <div className="space-y-2">
            {practiceHistory.slice(0, 5).map((p) => (
              <div
                key={p.id}
                className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs"
              >
                <span className="font-semibold text-white truncate max-w-xs">{p.challenge}</span>
                <Badge color={p.score >= 80 ? 'emerald' : 'amber'}>
                  {p.score} / 100
                </Badge>
              </div>
            ))}
            {practiceHistory.length === 0 && (
              <p className="text-xs text-slate-400 py-4 text-center">No lab practice recorded yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
