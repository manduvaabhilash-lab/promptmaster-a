import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  TrendingUp,
  Award,
  FlaskConical,
  MessageSquare,
  BookOpen,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Clock
} from 'lucide-react';
import api from '../api/client';
import LoadingSpinner from '../components/LoadingSpinner';
import Badge from '../components/Badge';

export const DashboardPage = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProgress = async () => {
      try {
        const res = await api.get('/progress');
        setData(res.data);
      } catch (err) {
        console.error('Failed to load dashboard data:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProgress();
  }, []);

  if (loading) {
    return <LoadingSpinner text="Loading your dashboard..." size="lg" />;
  }

  const progressPct = data?.learning_progress_pct || 0;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Student Dashboard</h1>
          <p className="text-sm text-slate-400">
            Track your prompt engineering progress, quiz performance, and active sessions.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Link
            to="/practice"
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-brand-600 hover:bg-brand-500 shadow-md shadow-brand-600/20 transition"
          >
            <FlaskConical className="w-3.5 h-3.5" />
            <span>New Practice Attempt</span>
          </Link>
          <Link
            to="/chat"
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition"
          >
            <MessageSquare className="w-3.5 h-3.5 text-brand-400" />
            <span>Open AI Chat</span>
          </Link>
        </div>
      </div>

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Progress Card */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold uppercase tracking-wider">Curriculum Progress</span>
            <BookOpen className="w-4 h-4 text-brand-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">{progressPct}%</span>
            <span className="text-xs text-slate-400">
              ({data?.topics_completed || 0}/{data?.total_topics || 7} modules)
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-brand-500 to-indigo-500 rounded-full transition-all duration-500"
              style={{ width: `${Math.max(progressPct, 5)}%` }}
            />
          </div>
        </div>

        {/* Quiz Score Card */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold uppercase tracking-wider">Avg Quiz Score</span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">{data?.avg_quiz_score || 0}%</span>
            <span className="text-xs text-slate-400">({data?.total_quizzes || 0} attempts)</span>
          </div>
          <p className="text-xs text-slate-400">
            Based on completed mini-quizzes and module evaluations.
          </p>
        </div>

        {/* Prompt Practice Score Card */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold uppercase tracking-wider">Prompt Lab Score</span>
            <FlaskConical className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">{data?.avg_practice_score || 0}</span>
            <span className="text-xs text-slate-400">/ 100 ({data?.total_practice || 0} attempts)</span>
          </div>
          <p className="text-xs text-slate-400">
            Scored on Clarity, Context, Constraints, and Format.
          </p>
        </div>

        {/* Saved Prompts Card */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold uppercase tracking-wider">Saved Templates</span>
            <Sparkles className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-white">{data?.saved_prompts_count || 0}</span>
            <span className="text-xs text-slate-400">templates</span>
          </div>
          <Link
            to="/prompt-generator"
            className="inline-flex items-center gap-1 text-xs text-brand-400 hover:text-brand-300 font-medium"
          >
            <span>Generate & Save More</span>
            <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>

      {/* Main Grid: Recent Conversations & Recommended Topics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recommended Topics */}
        <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-brand-400" />
              <span>Recommended Topics</span>
            </h3>
            <Link to="/learn" className="text-xs text-brand-400 hover:text-brand-300 font-semibold">
              View All
            </Link>
          </div>

          <div className="space-y-3">
            {data?.recommended_topics && data.recommended_topics.length > 0 ? (
              data.recommended_topics.map((topic) => (
                <Link
                  key={topic.id}
                  to={`/learn/${topic.id}`}
                  className="p-4 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-slate-700 transition flex items-center justify-between group block"
                >
                  <div className="space-y-1 pr-3">
                    <div className="flex items-center gap-2">
                      <Badge color="blue">{topic.badge}</Badge>
                      <span className="text-xs text-slate-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {topic.reading_time}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-white group-hover:text-brand-300 transition-colors">
                      {topic.title}
                    </h4>
                    <p className="text-xs text-slate-300 line-clamp-1">{topic.overview}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-brand-400 group-hover:translate-x-1 transition" />
                </Link>
              ))
            ) : (
              <p className="text-xs text-slate-400">All primary topics explored! Check the Quiz section to test your knowledge.</p>
            )}
          </div>
        </div>

        {/* Recent Conversations */}
        <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-400" />
              <span>Recent AI Conversations</span>
            </h3>
            <Link to="/chat" className="text-xs text-brand-400 hover:text-brand-300 font-semibold">
              New Chat
            </Link>
          </div>

          <div className="space-y-3">
            {data?.recent_conversations && data.recent_conversations.length > 0 ? (
              data.recent_conversations.map((conv) => (
                <Link
                  key={conv.id}
                  to={`/chat?c=${conv.id}`}
                  className="p-3.5 rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-slate-700 transition flex items-center justify-between group block"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                      <MessageSquare className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-white group-hover:text-brand-300 transition-colors truncate max-w-xs">
                        {conv.title}
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        Updated {new Date(conv.updated_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-brand-400 group-hover:translate-x-1 transition" />
                </Link>
              ))
            ) : (
              <div className="text-center py-8 space-y-3">
                <MessageSquare className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400">No chat history yet.</p>
                <Link
                  to="/chat"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white text-xs font-semibold"
                >
                  Start a Conversation
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
