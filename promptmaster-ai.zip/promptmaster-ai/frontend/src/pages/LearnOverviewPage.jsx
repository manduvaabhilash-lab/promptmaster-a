import React, { useState, useEffect } from 'react';
import { BookOpen, Sparkles, Search } from 'lucide-react';
import api from '../api/client';
import TopicCard from '../components/TopicCard';
import LoadingSpinner from '../components/LoadingSpinner';

export const LearnOverviewPage = () => {
  const [topics, setTopics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchTopics = async () => {
      try {
        const res = await api.get('/topics');
        setTopics(res.data);
      } catch (err) {
        console.error('Failed to load topics:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchTopics();
  }, []);

  const filteredTopics = topics.filter(
    (t) =>
      t.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.subtitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.overview.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs font-semibold mb-2">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Comprehensive 7-Module Curriculum</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">Prompt Engineering Curriculum</h1>
          <p className="text-sm text-slate-400 max-w-xl">
            Master the theoretical principles and industrial methodologies required to build dependable AI systems.
          </p>
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search topics or concepts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-brand-500"
          />
        </div>
      </div>

      {loading ? (
        <LoadingSpinner text="Loading curriculum modules..." size="lg" />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTopics.map((topic) => (
            <TopicCard key={topic.id} topic={topic} />
          ))}
          {filteredTopics.length === 0 && (
            <div className="col-span-full text-center py-16 text-slate-400">
              <p>No topics matching "{searchTerm}". Try a different keyword.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default LearnOverviewPage;
