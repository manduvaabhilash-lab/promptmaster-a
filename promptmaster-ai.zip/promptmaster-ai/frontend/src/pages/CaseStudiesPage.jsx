import React, { useState } from 'react';
import { Briefcase, BookOpen, HeartPulse, Terminal, Headset, Landmark, UserCheck, Sparkles, AlertTriangle, CheckCircle2 } from 'lucide-react';
import Badge from '../components/Badge';
import CodeBlock from '../components/CodeBlock';

const CASE_STUDIES = [
  {
    id: 'education',
    domain: 'Education & Learning',
    title: 'Adaptive Socratic AI Tutor',
    icon: BookOpen,
    badge: 'Pedagogy',
    problem: 'Students paste homework assignments into LLMs to generate direct answers, bypassing conceptual understanding and critical thinking.',
    naive_prompt: 'Solve this calculus derivative problem for me: f(x) = x^3 * sin(x).',
    naive_response: 'f\'(x) = 3x^2 * sin(x) + x^3 * cos(x). Here is the full step-by-step solution for your homework.',
    risks: 'Student copies answer without understanding the product rule or derivative mechanics.',
    benefits: 'Active inquiry increases long-term retention and conceptual confidence.',
    improved_prompt: `You are an encouraging university calculus tutor. A student asks for help with: f(x) = x^3 * sin(x).
Pedagogical Directives:
1. Do NOT give the final answer or compute the full derivative immediately.
2. Ask the student which differentiation rule applies when two functions are multiplied together.
3. Prompt them to identify what u(x) and v(x) are in this expression.
4. Provide a supportive hint and wait for the student's reply before progressing.`,
    outcome: 'Student actively identifies the Product Rule: (u*v)\' = u\'v + uv\', practicing active recall and mastering the underlying theorem.'
  },
  {
    id: 'healthcare',
    domain: 'Healthcare & Clinical Support',
    title: 'Discharge Summary Synthesis',
    icon: HeartPulse,
    badge: 'High Stakes & Safety',
    problem: 'Physicians spend up to 2 hours per shift formatting unstructured electronic health record (EHR) encounter notes into formal hospital discharge summaries.',
    naive_prompt: 'Write a discharge summary based on these doctor notes: Pt adm for SOB and bilat leg edema. Given IV Lasix. Improved. D/C on oral furosemide 40mg daily.',
    naive_response: 'Discharge Summary: Patient admitted with shortness of breath and congestive heart failure. Treated with Lasix. Discharge meds: Furosemide 40mg.',
    risks: 'Extrapolating unconfirmed diagnoses (e.g. diagnosing CHF when notes only state SOB) and medication hallucinations without physician sign-off.',
    benefits: 'Saves 45 minutes per discharge while standardizing documentation structure.',
    improved_prompt: `You are a clinical documentation assistant. Format the encounter notes into a standardized hospital discharge summary.
Mandatory Clinical Guardrails:
- Extract ONLY facts explicitly stated in the source notes.
- Do NOT diagnose conditions not documented by the physician.
- Include mandatory sections: [Primary Complaint, Hospital Course, Discharge Medications, Warning Signs].
- Append: "CRITICAL: Must be reviewed and co-signed by the attending licensed physician before transmission to patient chart."`,
    outcome: 'Structured, verifiable discharge document generated in 8 seconds with zero ungrounded clinical extrapolation.'
  },
  {
    id: 'software',
    domain: 'Software Engineering',
    title: 'Automated Unit Test Generation',
    icon: Terminal,
    badge: 'Developer Velocity',
    problem: 'Engineering teams often write unit tests only for happy paths, missing concurrency race conditions, null payloads, and timeout edge cases.',
    naive_prompt: 'Write unit tests for this payment processing function.',
    naive_response: 'def test_payment(): assert process_payment(100) == True',
    risks: 'Trivial assertions that pass without validating boundary conditions or mocking payment gateways.',
    benefits: 'Boosts test coverage to 95%+ and prevents regression incidents in CI/CD.',
    improved_prompt: `You are a Principal Software Quality Assurance Engineer specializing in pytest and asynchronous Python.
Generate a comprehensive test suite for \`process_payment_event(event: Dict) -> PaymentResult\`.
Coverage Requirements:
1. Valid transaction with 3D Secure verification.
2. Edge cases: zero amount, negative amount, currency mismatch.
3. Network error handling: mock Stripe gateway timeouts and retry exhaustion.
4. Use pytest fixtures and pytest-mock; never make live network calls.`,
    outcome: 'Generated 8 isolated pytest test cases with mocks, uncovering an unhandled gateway timeout exception prior to production deployment.'
  },
  {
    id: 'support',
    domain: 'Customer Support',
    title: 'Multi-Turn Sentiment De-escalation',
    icon: Headset,
    badge: 'Customer Care',
    problem: 'Frustrated customers with delayed orders receive robotic, boilerplate auto-replies, leading to social media escalations.',
    naive_prompt: 'Respond to this angry customer whose package was delayed: "Where is my order? This is ridiculous!"',
    naive_response: 'Dear customer, your tracking number is 9928. Shipping delays are beyond our control. Thank you.',
    risks: 'Defensive, unempathetic tone escalates customer anger.',
    benefits: 'Transforms negative interactions into positive brand sentiment and retention.',
    improved_prompt: `You are a senior customer care specialist with expertise in conflict de-escalation.
A long-time customer is frustrated by an unexpected 4-day shipping delay.
Response Guidelines:
1. Begin with an empathetic acknowledgement of the disruption without being defensive.
2. Clearly explain the current package status and provide a verified delivery window.
3. Automatically apply a $15 account courtesy credit for the inconvenience.
4. Maintain a warm, respectful, and professional executive tone.`,
    outcome: 'Customer thanked the support team for proactive credit and gave a 5-star post-resolution CSAT rating.'
  },
  {
    id: 'banking',
    domain: 'Banking & Fraud Detection',
    title: 'Transaction Anomaly Explanation',
    icon: Landmark,
    badge: 'Regulatory Compliance',
    problem: 'Machine learning fraud models output numerical risk scores (e.g., 0.89) that human fraud investigators struggle to audit quickly under regulatory deadlines.',
    naive_prompt: 'Why did the ML model flag this transaction as fraud: Account 9021, Amount $4,200, Geo: Lagos?',
    naive_response: 'The transaction is fraudulent because of the foreign location and high amount.',
    risks: 'Hallucinating ungrounded fraud assertions without examining cardholder velocity or historical travel notices.',
    benefits: 'Transparent audit trails satisfying regulatory compliance (FinCEN/SAR).',
    improved_prompt: `You are a bank fraud compliance analyst. Synthesize the anomaly signals for flagged transaction #9021 into an investigator brief.
Requirements:
- Correlate: (1) Baseline spending velocity vs (2) Current transaction characteristics.
- Check whether an active travel notice is recorded on file.
- State: "DECISION GATE: Human fraud specialist authorization required to freeze account."
- Format as bullet points with factual citations.`,
    outcome: 'Fraud analyst reviewed evidence in 90 seconds and confirmed authorized business travel, preventing false-positive account lockout.'
  },
  {
    id: 'recruiting',
    domain: 'Resume Analysis & Talent Acquisition',
    title: 'Objective Competency Matching',
    icon: UserCheck,
    badge: 'Talent Acquisition',
    problem: 'Traditional resume screening prompts suffer from subjective bias, favoring candidates from specific universities or penalizing non-traditional career paths.',
    naive_prompt: 'Is this candidate good enough for our senior engineer job?',
    naive_response: 'Yes, they went to Stanford and have worked at top companies.',
    risks: 'Prestige bias and systemic omission of self-taught or non-traditional engineers.',
    benefits: 'Objective skill-grounded shortlisting with demographic blind assessment.',
    improved_prompt: `You are an objective technical recruiter. Evaluate candidate resume text against the job description for Senior Backend Engineer.
Evaluation Rubric:
- Score 1 to 5 on: System Architecture, Python Concurrency, PostgreSQL Optimization, and Mentorship.
- Do NOT consider university pedigree, personal names, graduation years, or geographic location.
- Cite specific code or project achievements from the resume for each score.`,
    outcome: 'Discovered high-performing candidate with non-traditional background who outperformed all candidates on technical interview stages.'
  }
];

export const CaseStudiesPage = () => {
  const [selectedCase, setSelectedCase] = useState(CASE_STUDIES[0]);

  return (
    <div className="space-y-12 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-semibold mb-2">
          <Briefcase className="w-3.5 h-3.5" />
          <span>Enterprise Industry Playbooks</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">Real-World Case Studies</h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Real-world failure modes, production prompt patterns, and measurable business outcomes across 6 industry sectors.
        </p>
      </div>

      {/* Domain Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {CASE_STUDIES.map((cs) => {
          const Icon = cs.icon;
          return (
            <button
              key={cs.id}
              onClick={() => setSelectedCase(cs)}
              className={`px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition flex items-center gap-2 ${
                selectedCase.id === cs.id
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{cs.domain}</span>
            </button>
          );
        })}
      </div>

      {/* Case Study Deep Dive */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-8">
        {/* Title & Problem Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Badge color="purple">{selectedCase.badge}</Badge>
              <span className="text-xs text-slate-400 font-mono">{selectedCase.domain}</span>
            </div>
            <h2 className="text-2xl font-bold text-white">{selectedCase.title}</h2>
          </div>
        </div>

        {/* Problem Statement */}
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5">
          <span className="text-xs font-bold text-brand-400 uppercase tracking-wider">
            Operational Challenge:
          </span>
          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
            {selectedCase.problem}
          </p>
        </div>

        {/* Naive vs Engineered Diffs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Naive Prompt & Fragile Completion */}
          <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-900/30 space-y-3">
            <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">
              ❌ Naive Approach & Fragile Response
            </span>
            <div className="p-3 rounded-xl bg-slate-950/80 border border-rose-900/40 text-xs font-mono text-rose-200">
              "{selectedCase.naive_prompt}"
            </div>
            <div className="text-xs text-slate-400 pt-1">
              <span className="font-semibold text-rose-300">Failure Risks: </span>
              {selectedCase.risks}
            </div>
          </div>

          {/* Engineered Prompt & Protected Outcome */}
          <div className="p-5 rounded-2xl bg-purple-950/20 border border-purple-900/30 space-y-3">
            <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
              ✅ Production-Grade Prompt
            </span>
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-purple-900/40 text-xs font-mono text-purple-200 whitespace-pre-wrap leading-relaxed">
              {selectedCase.improved_prompt}
            </div>
          </div>
        </div>

        {/* Measurable Business Outcome */}
        <div className="p-5 rounded-2xl bg-emerald-950/20 border border-emerald-900/40 space-y-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <h4 className="text-sm font-bold text-emerald-300">Verified Business Outcome</h4>
          </div>
          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed pl-7">
            {selectedCase.outcome}
          </p>
        </div>
      </div>
    </div>
  );
};

export default CaseStudiesPage;
