import React, { useState } from 'react';
import { Layers, Copy, Check, Sparkles, ArrowRight, BookOpen, Code, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Badge from '../components/Badge';
import CodeBlock from '../components/CodeBlock';

const PROMPT_TYPES = [
  {
    id: 'zero-shot',
    title: 'Zero-Shot Prompting',
    badge: 'Baseline',
    summary: 'Directly querying the model without providing reference demonstrations or examples.',
    definition: 'Zero-shot prompting presents a task directly to an LLM, relying exclusively on the parameters and semantic priors learned during initial pretraining and post-training alignment.',
    when_to_use: 'Best for standard knowledge retrieval, general summaries, translations, and everyday tasks where the desired output format is obvious or flexible.',
    advantages: [
      'Minimal token consumption and lowest API latency.',
      'Simple to author without assembling labeled dataset examples.',
      'Tests raw out-of-the-box model reasoning.'
    ],
    limitations: [
      'Unreliable for bespoke corporate schemas or proprietary classifications.',
      'Higher variance in phrasing and structural verbosity.',
      'Cannot guide subtle edge-case distinctions.'
    ],
    example: `Classify the sentiment of the following customer comment as Positive, Negative, or Neutral:

"The software installed without issues, but the documentation is missing examples for the API."

Sentiment:`,
    sample_output: `Neutral (or Mixed): The comment acknowledges successful installation but notes an operational shortcoming in documentation.`
  },
  {
    id: 'one-shot',
    title: 'One-Shot Prompting',
    badge: 'Single Anchor',
    summary: 'Providing exactly one input-output demonstration to anchor the expected schema.',
    definition: 'One-shot prompting introduces a single exemplar before the target request. This single demonstration anchors format, capitalization, and tone via in-context learning.',
    when_to_use: 'When the model is failing on syntax or style in zero-shot, but you want to conserve prompt token budgets.',
    advantages: [
      'Dramatically reduces formatting errors compared to zero-shot.',
      'Low token footprint (only one example).',
      'Provides an instant structural template.'
    ],
    limitations: [
      'Single examples can cause the model to overfit to idiosyncratic details of that one exemplar.',
      'Insufficient for complex multi-class categorization boundaries.'
    ],
    example: `Convert casual date expressions into ISO 8601 format:

Input: "next Friday afternoon around 3pm"
Output: "2026-10-02T15:00:00"

Input: "tomorrow morning at 9am"
Output:`,
    sample_output: `"2026-09-28T09:00:00"`
  },
  {
    id: 'few-shot',
    title: 'Few-Shot Prompting',
    badge: 'In-Context Learning',
    summary: 'Providing 2 to 5 demonstrations to calibrate subtle classification boundaries and custom formats.',
    definition: 'Few-shot prompting provides multiple input-output pairs. This leverages In-Context Learning (ICL) to condition the self-attention mechanism on patterns, vocabulary, and edge-case heuristics.',
    when_to_use: 'Indispensable for custom domain entity extraction, strict JSON compliance, nuance-heavy sentiment detection, or matching specific brand voice.',
    advantages: [
      'Unmatched accuracy for non-standard labeling and structured outputs.',
      'Eliminates ambiguity on how boundary cases should be classified.',
      'Steers generation without updating underlying neural weights.'
    ],
    limitations: [
      'Consumes prompt token budget on every query, increasing inference costs.',
      'Susceptible to recency bias (overweighting the last exemplar).',
      'Requires curated, accurate demonstration pairs.'
    ],
    example: `Categorize the financial transaction and extract the merchant:

Transaction: "WHOLEFDS SOMA 10294 SAN FRANCISCO CA"
Category: Groceries
Merchant: Whole Foods

Transaction: "UBER TRIP HELP.UBER.COM CA"
Category: Transportation
Merchant: Uber

Transaction: "GITHUB INC 877-448-4820 CA"
Category: Software & Cloud
Merchant: GitHub

Transaction: "SHELL OIL 5744210 HOUSTON TX"
Category:`,
    sample_output: `Category: Fuel / Automobile\nMerchant: Shell`
  },
  {
    id: 'role-based',
    title: 'Role-Based Prompting',
    badge: 'Persona Steering',
    summary: 'Assigning a distinct expert persona or perspective to adjust vocabulary, rigor, and tone.',
    definition: 'Role-based prompting instructs the model to embody an explicit expert persona (e.g., Senior Systems Architect, Pediatrician, Legal Counsel). This primes attention heads with specialized domain vocabulary and expected levels of skepticism or technical depth.',
    when_to_use: 'When you need deep technical domain analysis, tailored reading levels, or specific communication personas.',
    advantages: [
      'Filters out casual conversational tone and pleasantries.',
      'Primes specialized domain vocabulary and industry best practices.',
      'Enables roleplay simulations and educational Socratic tutoring.'
    ],
    limitations: [
      'Assigning an expert persona does not grant the model real-world professional certifications or infallible truth.',
      'Can occasionally produce an overly pedantic or pompous register if not calibrated.'
    ],
    example: `You are an experienced Python developer specializing in asyncio and high-concurrency systems.
Review the following function for race conditions and suggest a production-ready fix using asyncio.Lock.

[PASTE FUNCTION HERE]`,
    sample_output: `Detailed code review identifying Shared State mutation hazards, followed by a thread-safe refactor utilizing asyncio.Lock and contextual error handling.`
  },
  {
    id: 'instruction',
    title: 'Instruction Prompting',
    badge: 'Task Breakdown',
    summary: 'Direct imperative instructions with explicit requirements and operational steps.',
    definition: 'Instruction prompting explicitly tells the model what operations to execute, what rules to enforce, and what negative conditions to prevent, often formatted as numbered steps.',
    when_to_use: 'Standard for programmatic AI workflows, document transformations, and automated processing pipelines.',
    advantages: [
      'High clarity and deterministic execution.',
      'Easy to maintain, version-control, and unit-test.',
      'Compatible with modern instruction-tuned foundation models.'
    ],
    limitations: [
      'Overly complex instructions can cause constraint conflicts where the model ignores one rule in favor of another.'
    ],
    example: `Summarize the following research article in 5 bullet points.
Requirements:
1. Each bullet point must not exceed 25 words.
2. Focus strictly on methodology and validated empirical outcomes.
3. Avoid subjective adjectives (e.g., 'groundbreaking', 'remarkable').
4. Conclude with a 'Limitations' statement.`,
    sample_output: `5 clean, concise bullet points adhering strictly to the word-count boundaries and objective tone.`
  },
  {
    id: 'structured',
    title: 'Structured Prompting (JSON/Schema)',
    badge: 'Data Contract',
    summary: 'Enforcing strict JSON, XML, or Markdown schemas for reliable programmatic downstream ingestion.',
    definition: 'Structured prompting specifies the exact machine-readable schema required. It commands the model to output purely valid data representations without markdown preambles or conversational commentary.',
    when_to_use: 'Whenever an application backend or database must parse the LLM completion via JSON.parse() or Pydantic.',
    advantages: [
      'Direct integration with REST APIs and databases.',
      'Eliminates fragile regex parsing of freeform text.',
      'Forces the model to organize its thoughts into relational hierarchies.'
    ],
    limitations: [
      'Without grammar constraints, the model may occasionally omit a closing bracket or include trailing commas.'
    ],
    example: `You are a database extraction engine. Extract user entities from the following text into valid JSON.
Return ONLY valid JSON matching this schema:
{
  "name": string,
  "role": string,
  "years_experience": number,
  "technologies": [string]
}

Text: "Alex Chen is a senior devops engineer with 7 years configuring Terraform, Docker, and Kubernetes on GCP."`,
    sample_output: `{\n  "name": "Alex Chen",\n  "role": "senior devops engineer",\n  "years_experience": 7,\n  "technologies": ["Terraform", "Docker", "Kubernetes", "GCP"]\n}`
  },
  {
    id: 'contextual',
    title: 'Contextual Prompting',
    badge: 'Grounding & RAG',
    summary: 'Supplying verified reference documents and grounding context to eliminate hallucinations.',
    definition: 'Contextual prompting provides the source truth directly inside the prompt context window. The model is instructed to formulate its answer strictly from the supplied text and declare uncertainty if facts are absent.',
    when_to_use: 'Enterprise search, legal document discovery, medical guideline lookups, and customer policy Q&A.',
    advantages: [
      'Near-complete mitigation of factual hallucinations.',
      'Enables exact citation of source clauses, paragraphs, or page numbers.',
      'Allows answering questions regarding private or post-cutoff information.'
    ],
    limitations: [
      'Prompt token costs scale linearly with the length of injected context.',
      'Susceptible to the "lost in the middle" attention attenuation phenomenon on very long documents.'
    ],
    example: `Context:
[Policy Doc #881: Employees receive 20 days of paid vacation per calendar year. Up to 5 unused days may roll over into the following year, expiring by March 31st.]

Instruction:
Using ONLY the Context provided above, answer:
How many days can an employee roll over, and when do those rolled-over days expire?
If the information is not in the Context, respond with "UNKNOWN".`,
    sample_output: `An employee may roll over up to 5 unused days, and those rolled-over days expire on March 31st of the following year.`
  }
];

export const PromptTypesPage = () => {
  const [selectedType, setSelectedType] = useState(PROMPT_TYPES[0]);
  const navigate = useNavigate();

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs font-semibold mb-2">
          <Layers className="w-3.5 h-3.5" />
          <span>Interactive Taxonomy Guide</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">Prompt Typology & Applications</h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Master the full spectrum of prompting paradigms—from zero-shot baseline queries to few-shot demonstrations, role steering, and schema-constrained extraction.
        </p>
      </div>

      {/* Type Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {PROMPT_TYPES.map((t) => (
          <button
            key={t.id}
            onClick={() => setSelectedType(t)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition flex items-center gap-2 ${
              selectedType.id === t.id
                ? 'bg-brand-600 text-white shadow-lg shadow-brand-600/30'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
            }`}
          >
            <span>{t.title}</span>
            <Badge color="blue" className="text-[10px]">{t.badge}</Badge>
          </button>
        ))}
      </div>

      {/* Main Details Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Definition & Analysis */}
        <div className="lg:col-span-6 space-y-6">
          <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="text-xl font-bold text-white">{selectedType.title}</h2>
              <Badge color="indigo">{selectedType.badge}</Badge>
            </div>

            <p className="text-sm text-brand-300 font-medium leading-relaxed">
              {selectedType.summary}
            </p>

            <div className="text-xs text-slate-300 leading-relaxed space-y-2">
              <div className="font-semibold text-white">Definition:</div>
              <p>{selectedType.definition}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs space-y-1">
              <span className="font-semibold text-brand-400">When to use: </span>
              <span className="text-slate-300">{selectedType.when_to_use}</span>
            </div>
          </div>

          {/* Advantages & Limitations */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-900/30 space-y-2">
              <h4 className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Advantages</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {selectedType.advantages.map((adv, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-emerald-400">•</span>
                    <span>{adv}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-900/30 space-y-2">
              <h4 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>Limitations</span>
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {selectedType.limitations.map((lim, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-amber-400">•</span>
                    <span>{lim}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Right: Concrete Example & Sandbox Actions */}
        <div className="lg:col-span-6 space-y-6">
          <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Executable Prompt Pattern
              </span>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(selectedType.example);
                  alert('Copied example prompt to clipboard!');
                }}
                className="text-xs text-brand-400 hover:text-brand-300 flex items-center gap-1 font-medium"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy Example</span>
              </button>
            </div>

            <div>
              <CodeBlock code={selectedType.example} language="markdown" title="Prompt Template" />
            </div>

            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-slate-400">Target Model Completion:</span>
              <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800 text-xs font-mono text-emerald-300 whitespace-pre-wrap">
                {selectedType.sample_output}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <button
                onClick={() => navigate(`/chat?topic=${encodeURIComponent(selectedType.title)}`)}
                className="flex items-center gap-1.5 text-xs font-semibold text-brand-400 hover:text-brand-300 transition"
              >
                <span>Ask AI about {selectedType.title}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => navigate('/practice')}
                className="px-4 py-2 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs shadow-md shadow-brand-600/20 transition"
              >
                Practice in Lab
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PromptTypesPage;
