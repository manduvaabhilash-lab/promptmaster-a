import React, { useState } from 'react';
import { Cpu, Layers, Sparkles, Database, Sliders, ArrowRight, ShieldCheck, Calculator, ExternalLink } from 'lucide-react';
import Badge from '../components/Badge';

const MODEL_FAMILIES = [
  {
    family: 'GPT Family',
    developer: 'OpenAI',
    badge: 'Proprietary API',
    overview: 'Pioneered autoregressive decoder-only Transformer scaling (GPT-3, GPT-4, GPT-4o). Renowned for general reasoning, function calling, and structured JSON output.',
    context_window: 'Up to 128k tokens',
    strengths: 'Instruction adherence, tool integration, JSON schema mode',
    architecture: 'Dense and Mixture-of-Experts (MoE) decoder Transformers'
  },
  {
    family: 'Gemini Family',
    developer: 'Google DeepMind',
    badge: 'Multimodal Foundation',
    overview: 'Natively multimodal from inception, processing video, audio, code, and text across unified latent spaces (Gemini Flash, Pro, Ultra).',
    context_window: 'Up to 1M - 2M tokens',
    strengths: 'Ultra-long context windows, native audio/video comprehension, speed efficiency',
    architecture: 'Multimodal Transformer with efficient sparse attention'
  },
  {
    family: 'Claude Family',
    developer: 'Anthropic',
    badge: 'Constitutional AI',
    overview: 'Built upon Constitutional AI alignment frameworks with emphasis on nuanced writing, document synthesis, and reduced sycophancy (Claude 3.5 Sonnet, Haiku, Opus).',
    context_window: 'Up to 200k tokens',
    strengths: 'Analytical writing, nuance comprehension, code reasoning, refusal accuracy',
    architecture: 'Autoregressive decoder-only Transformer with safety steerability'
  },
  {
    family: 'Llama Family',
    developer: 'Meta AI',
    badge: 'Open Weights',
    overview: 'Industry-standard open-weights foundation models (Llama 2, Llama 3/3.1/3.2), enabling local fine-tuning, on-premise private deployment, and academic research.',
    context_window: 'Up to 128k tokens',
    strengths: 'Data privacy, open weights customization, edge device inference (1B-70B+)',
    architecture: 'Standard dense decoder with RoPE and grouped-query attention (GQA)'
  },
  {
    family: 'Mistral & Mixtral',
    developer: 'Mistral AI',
    badge: 'Sparse MoE & Open',
    overview: 'Pioneered lightweight high-efficiency models and open Mixture-of-Experts (8x7B, 8x22B) delivering high throughput per parameter active during inference.',
    context_window: 'Up to 32k - 128k tokens',
    strengths: 'Parameter efficiency, low inference latency, multilingual European support',
    architecture: 'Sparse Mixture-of-Experts with sliding window attention'
  },
  {
    family: 'DeepSeek Family',
    developer: 'DeepSeek AI',
    badge: 'Open Architecture & MoE',
    overview: 'Specialized open foundation models utilizing Multi-head Latent Attention (MLA) and DeepSeekMoE architectures for mathematical reasoning and code generation.',
    context_window: 'Up to 64k - 128k tokens',
    strengths: 'Mathematical reasoning, code completion, high token efficiency',
    architecture: 'Multi-head Latent Attention (MLA) with auxiliary-loss-free load balancing'
  }
];

export const LLMModelsPage = () => {
  const [inputText, setInputText] = useState(
    'Prompt engineering unlocks the capabilities of Large Language Models.'
  );

  // Interactive Tokenizer estimation
  const words = inputText.trim() ? inputText.trim().split(/\s+/) : [];
  const estimatedTokens = Math.max(Math.round(words.length * 1.3), words.length > 0 ? 1 : 0);
  const characterCount = inputText.length;

  return (
    <div className="space-y-12 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/30 text-brand-300 text-xs font-semibold mb-2">
          <Cpu className="w-3.5 h-3.5" />
          <span>Architecture & Landscape</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white">Large Language Models (LLMs)</h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Understand how foundation models process tokens, compute self-attention, and predict next-token probability distributions.
        </p>
      </div>

      {/* High-Level Overview Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-3">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-brand-400" />
            <span>What is an LLM?</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            A Large Language Model (LLM) is a deep artificial neural network with billions of parameters, trained on vast corpora of text to model the statistical structure of human language.
          </p>
          <p className="text-xs text-slate-400 leading-relaxed">
            Rather than looking up facts in a traditional database, an LLM is a continuous mathematical function that receives an input sequence of tokens and predicts the probability distribution for the next token:
            <span className="block font-mono text-brand-300 bg-slate-950 p-2 rounded-lg mt-2 text-center text-xs">
              P(next_token | prompt_tokens)
            </span>
          </p>
        </div>

        <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-3">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-400" />
            <span>The 6 Core Architectural Layers</span>
          </h2>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-brand-400">1. Tokenization</span>
              <p className="text-[11px] text-slate-400">Splitting text into BPE subwords</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-brand-400">2. Embeddings</span>
              <p className="text-[11px] text-slate-400">High-dimensional continuous vectors</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-brand-400">3. Self-Attention</span>
              <p className="text-[11px] text-slate-400">Relational weighting across context</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-brand-400">4. Feed-Forward</span>
              <p className="text-[11px] text-slate-400">Dense non-linear projections</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-brand-400">5. Context Window</span>
              <p className="text-[11px] text-slate-400">Active working memory buffer</p>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="font-bold text-brand-400">6. Inference</span>
              <p className="text-[11px] text-slate-400">Greedy or nucleus sampling</p>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Tokenizer Visualizer */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-white">Interactive Tokenizer & Cost Estimator</h3>
          </div>
          <Badge color="emerald">Live Explorer</Badge>
        </div>

        <p className="text-xs text-slate-400">
          LLMs do not read characters or words—they process tokens (typically 3-4 characters in English). Test how text maps to tokens below:
        </p>

        <textarea
          rows="3"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Type or paste text to inspect estimated tokens..."
          className="w-full p-3.5 rounded-xl bg-slate-950/80 border border-slate-700 text-xs sm:text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-brand-500 resize-none"
        />

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-xl font-bold text-white font-mono">{characterCount}</div>
            <div className="text-[11px] text-slate-400">Characters</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-xl font-bold text-white font-mono">{words.length}</div>
            <div className="text-[11px] text-slate-400">Words</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-xl font-bold text-emerald-400 font-mono">~{estimatedTokens}</div>
            <div className="text-[11px] text-slate-400">Estimated Tokens</div>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-xl font-bold text-brand-400 font-mono">
              ${((estimatedTokens / 1000000) * 0.15).toFixed(6)}
            </div>
            <div className="text-[11px] text-slate-400">Input Cost @ $0.15/1M</div>
          </div>
        </div>
      </div>

      {/* Model Family Information Cards */}
      <div className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-white">Representative Model Families</h2>
          <p className="text-xs text-slate-400">
            Educational overview of prominent architectural paradigms. Presented without unsupported ranking claims.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {MODEL_FAMILIES.map((model) => (
            <div
              key={model.family}
              className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col justify-between space-y-4 hover:border-slate-700 transition"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-base font-bold text-white">{model.family}</h3>
                  <Badge color="blue">{model.badge}</Badge>
                </div>
                <div className="text-xs text-brand-400 font-medium mb-3">
                  Developer: {model.developer}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {model.overview}
                </p>

                <div className="space-y-2 text-xs border-t border-slate-800/80 pt-3">
                  <div>
                    <span className="font-semibold text-slate-400">Context Window: </span>
                    <span className="text-slate-200 font-mono">{model.context_window}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-400">Architecture: </span>
                    <span className="text-slate-300">{model.architecture}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-400">Core Strengths: </span>
                    <span className="text-slate-300">{model.strengths}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LLMModelsPage;
