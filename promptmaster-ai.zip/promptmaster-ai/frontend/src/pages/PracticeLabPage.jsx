import React, { useState, useEffect } from 'react';
import {
  FlaskConical,
  Award,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Send,
  HelpCircle,
  Sliders,
  History
} from 'lucide-react';
import api from '../api/client';
import LoadingSpinner from '../components/LoadingSpinner';
import Badge from '../components/Badge';
import CodeBlock from '../components/CodeBlock';

export const PracticeLabPage = () => {
  const [challenges, setChallenges] = useState([]);
  const [selectedChallenge, setSelectedChallenge] = useState(null);
  const [isCustomMode, setIsCustomMode] = useState(false);
  const [customTitle, setCustomTitle] = useState('');
  const [promptText, setPromptText] = useState('');
  const [evaluating, setEvaluating] = useState(false);
  const [evalResult, setEvalResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [activeTab, setActiveTab] = useState('editor'); // 'editor' or 'history'
  const [copiedRewrite, setCopiedRewrite] = useState(false);

  useEffect(() => {
    const fetchChallenges = async () => {
      try {
        const res = await api.get('/practice/challenges');
        setChallenges(res.data);
        if (res.data.length > 0) {
          setSelectedChallenge(res.data[0]);
        }
      } catch (err) {
        console.error('Failed to load challenges:', err);
      }
    };
    fetchChallenges();
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    try {
      const res = await api.get('/practice/history');
      setHistory(res.data);
    } catch (err) {
      console.error('Failed to load history:', err);
    }
  };

  const handleEvaluate = async () => {
    if (!promptText.trim()) return;

    setEvaluating(true);
    setEvalResult(null);

    const challengeName = isCustomMode
      ? customTitle.trim() || 'Custom Challenge'
      : selectedChallenge?.title || 'Challenge';

    try {
      const res = await api.post('/prompt/evaluate', {
        challenge: challengeName,
        prompt: promptText.trim(),
      });
      setEvalResult(res.data);
      fetchHistory();
    } catch (err) {
      console.error('Evaluation failed:', err);
    } finally {
      setEvaluating(false);
    }
  };

  const handleCopyRewrite = (text) => {
    navigator.clipboard.writeText(text);
    setCopiedRewrite(true);
    setTimeout(() => setCopiedRewrite(false), 2000);
  };

  const currentChallengeText = isCustomMode
    ? customTitle || 'Custom Prompt Challenge'
    : selectedChallenge?.description || '';

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-2">
            <FlaskConical className="w-3.5 h-3.5" />
            <span>Interactive Prompt Evaluation Lab</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">Prompt Practice Lab</h1>
          <p className="text-sm text-slate-400 max-w-xl">
            Draft prompts against benchmark challenges and receive automated scoring across 5 rubric dimensions.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 p-1 rounded-xl bg-slate-900 border border-slate-800">
          <button
            onClick={() => setActiveTab('editor')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeTab === 'editor'
                ? 'bg-brand-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FlaskConical className="w-3.5 h-3.5" />
            <span>Lab Editor</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeTab === 'history'
                ? 'bg-brand-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Attempt History ({history.length})</span>
          </button>
        </div>
      </div>

      {activeTab === 'editor' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Challenge Selector & Editor */}
          <div className="lg:col-span-7 space-y-6">
            {/* Challenge Picker */}
            <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Select a Benchmark Challenge
                </span>
                <button
                  onClick={() => setIsCustomMode(!isCustomMode)}
                  className="text-xs text-brand-400 hover:text-brand-300 font-semibold"
                >
                  {isCustomMode ? 'Choose Preset Challenge' : '+ Create Custom Challenge'}
                </button>
              </div>

              {!isCustomMode ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {challenges.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        setSelectedChallenge(c);
                        setEvalResult(null);
                      }}
                      className={`text-left p-3 rounded-xl border text-xs transition space-y-1 ${
                        selectedChallenge?.id === c.id
                          ? 'border-brand-500 bg-brand-500/10 text-white font-medium shadow-md shadow-brand-500/10'
                          : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold truncate">{c.title}</span>
                        <Badge color="blue" className="text-[10px]">{c.difficulty}</Badge>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">{c.category}</p>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={customTitle}
                    onChange={(e) => setCustomTitle(e.target.value)}
                    placeholder="Enter custom challenge goal (e.g. Extract JSON from email)"
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-brand-500"
                  />
                </div>
              )}

              {/* Challenge Details Card */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-brand-400" />
                  <span className="text-xs font-bold text-white">Challenge Objective</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed font-mono">
                  {currentChallengeText}
                </p>
                {selectedChallenge?.ideal_criteria && !isCustomMode && (
                  <p className="text-[11px] text-slate-400 pt-1">
                    <span className="font-semibold text-slate-300">Target Criteria: </span>
                    {selectedChallenge.ideal_criteria}
                  </p>
                )}
              </div>
            </div>

            {/* Prompt Workspace Editor */}
            <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Your Draft Prompt
                </span>
                <span className="text-xs font-mono text-slate-400">
                  {promptText.trim().split(/\s+/).filter(Boolean).length} words | {promptText.length} chars
                </span>
              </div>

              <textarea
                rows="8"
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                placeholder="Write your prompt here... For example: You are an expert researcher. Summarize the text below in exactly five bullet points..."
                className="w-full p-4 rounded-xl bg-slate-950/80 border border-slate-700/80 text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-brand-500 leading-relaxed resize-y"
              />

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => {
                    if (selectedChallenge?.sample_good_prompt) {
                      setPromptText(selectedChallenge.sample_good_prompt);
                    }
                  }}
                  className="text-xs text-slate-400 hover:text-brand-300 font-medium transition"
                >
                  Load Sample Benchmark Prompt
                </button>

                <button
                  onClick={handleEvaluate}
                  disabled={!promptText.trim() || evaluating}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-brand-600 hover:from-emerald-500 hover:to-brand-500 disabled:opacity-40 text-white font-semibold text-xs transition shadow-lg shadow-emerald-600/20"
                >
                  {evaluating ? (
                    <span>Analyzing Rubric...</span>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Evaluate Prompt</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Evaluation Scorecard */}
          <div className="lg:col-span-5 space-y-6">
            {evaluating ? (
              <div className="glass-card rounded-2xl p-12 border border-slate-800 text-center">
                <LoadingSpinner text="Evaluating prompt against rubric criteria..." size="lg" />
              </div>
            ) : evalResult ? (
              <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-6 animate-fade-in">
                {/* Score Header */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Evaluation Result
                    </span>
                    <h3 className="text-2xl font-black text-white">
                      {evalResult.score} <span className="text-sm font-medium text-slate-400">/ 100</span>
                    </h3>
                  </div>
                  <Badge
                    color={
                      evalResult.score >= 80 ? 'emerald' : evalResult.score >= 60 ? 'amber' : 'rose'
                    }
                    className="text-sm px-3 py-1"
                  >
                    {evalResult.score >= 80 ? 'Production Ready' : evalResult.score >= 60 ? 'Needs Polish' : 'Iterate Prompt'}
                  </Badge>
                </div>

                {/* Score Breakdown Bars */}
                <div className="space-y-3">
                  <span className="text-xs font-semibold text-slate-300">Rubric Dimensions</span>
                  {[
                    { name: 'Clarity', obj: evalResult.clarity },
                    { name: 'Context', obj: evalResult.context },
                    { name: 'Specificity', obj: evalResult.specificity },
                    { name: 'Constraints', obj: evalResult.constraints },
                    { name: 'Output Format', obj: evalResult.output_format },
                  ].map((metric) => {
                    const pct = ((metric.obj?.score || 10) / 20) * 100;
                    return (
                      <div key={metric.name} className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-300 font-medium">{metric.name}</span>
                          <span className="font-mono text-slate-400">
                            {metric.obj?.score || 0} / 20
                          </span>
                        </div>
                        <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              pct >= 75 ? 'bg-emerald-500' : pct >= 50 ? 'bg-amber-500' : 'bg-rose-500'
                            }`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        {metric.obj?.comment && (
                          <div className="text-[10px] text-slate-400 italic">
                            {metric.obj.comment}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Suggestions List */}
                {evalResult.suggestions && evalResult.suggestions.length > 0 && (
                  <div className="space-y-2 pt-2">
                    <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                      <span>Targeted Improvements:</span>
                    </span>
                    <ul className="space-y-1.5">
                      {evalResult.suggestions.map((s, idx) => (
                        <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                          <span className="text-amber-400 font-bold shrink-0">{idx + 1}.</span>
                          <span>{s}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* AI Improved Rewrite */}
                {evalResult.improved_prompt && (
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Recommended Optimized Rewrite</span>
                      </span>
                      <button
                        onClick={() => handleCopyRewrite(evalResult.improved_prompt)}
                        className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                      >
                        {copiedRewrite ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-slate-300 whitespace-pre-wrap max-h-48 overflow-y-auto">
                      {evalResult.improved_prompt}
                    </div>
                  </div>
                )}

                {/* Simulated Output Preview */}
                {evalResult.simulated_output && (
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <span className="text-xs font-semibold text-slate-400">
                      Simulated LLM Completion Preview:
                    </span>
                    <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 whitespace-pre-wrap max-h-40 overflow-y-auto leading-relaxed">
                      {evalResult.simulated_output}
                    </div>
                  </div>
                )}

                {/* Intelligence Disclaimer */}
                <div className="text-[10px] text-slate-400 text-center italic pt-2 border-t border-slate-800/80">
                  Note: This score evaluates prompt engineering criteria (clarity, constraints, formatting) and is not an assessment of human intelligence.
                </div>
              </div>
            ) : (
              <div className="glass-card rounded-2xl p-8 border border-slate-800 text-center space-y-4">
                <div className="w-12 h-12 rounded-xl bg-slate-900 text-slate-500 flex items-center justify-center mx-auto">
                  <Award className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">Scorecard Pending</h4>
                <p className="text-xs text-slate-400 max-w-xs mx-auto leading-relaxed">
                  Draft your prompt on the left and click "Evaluate Prompt" to receive instant multi-metric feedback and actionable optimization suggestions.
                </p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* History View */
        <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <History className="w-5 h-5 text-brand-400" />
            <span>Past Prompt Practice Attempts</span>
          </h3>

          <div className="space-y-3">
            {history.map((att) => (
              <div
                key={att.id}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">{att.challenge}</span>
                    <Badge color={att.score >= 80 ? 'emerald' : 'amber'}>
                      {att.score} / 100
                    </Badge>
                  </div>
                  <p className="text-xs font-mono text-slate-400 line-clamp-1">{att.prompt}</p>
                </div>
                <div className="text-xs text-slate-400">
                  {new Date(att.created_at).toLocaleDateString()}
                </div>
              </div>
            ))}

            {history.length === 0 && (
              <div className="text-center py-12 text-slate-400 text-xs">
                No past attempts recorded. Complete a challenge to view your history here!
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default PracticeLabPage;
