import React, { useState, useEffect } from 'react';
import { HelpCircle, Award, CheckCircle2, XCircle, RotateCcw, ArrowRight, BookOpen, History, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import LoadingSpinner from '../components/LoadingSpinner';
import Badge from '../components/Badge';

export const QuizPage = () => {
  const [topics, setTopics] = useState([]);
  const [selectedTopic, setSelectedTopic] = useState('all');
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Active quiz state
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [activeTab, setActiveTab] = useState('quiz'); // 'quiz' or 'history'

  const fetchQuestions = async (topicSlug) => {
    setLoading(true);
    setResult(null);
    setAnswers({});
    setCurrentQuestionIndex(0);
    try {
      const res = await api.get(`/quiz/questions?topic=${topicSlug}`);
      setQuestions(res.data);
    } catch (err) {
      console.error('Failed to load quiz questions:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await api.get('/quiz/history');
      setHistory(res.data);
    } catch (err) {
      console.error('Failed to load quiz history:', err);
    }
  };

  useEffect(() => {
    const fetchInitial = async () => {
      try {
        const tRes = await api.get('/topics');
        setTopics(tRes.data);
      } catch (err) {
        console.error('Failed to load topics list:', err);
      }
      fetchQuestions('all');
      fetchHistory();
    };
    fetchInitial();
  }, []);

  const handleTopicChange = (slug) => {
    setSelectedTopic(slug);
    fetchQuestions(slug);
  };

  const handleSelectOption = (optIndex) => {
    if (result) return;
    const currentQ = questions[currentQuestionIndex];
    if (currentQ) {
      setAnswers((prev) => ({ ...prev, [currentQ.id]: optIndex }));
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    const answersPayload = Object.entries(answers).map(([qId, opt]) => ({
      question_id: parseInt(qId),
      selected_option: opt,
    }));

    try {
      const res = await api.post('/quiz/submit', {
        topic: selectedTopic,
        answers: answersPayload,
      });
      setResult(res.data);
      fetchHistory();
    } catch (err) {
      console.error('Failed to submit quiz:', err);
    } finally {
      setSubmitting(false);
    }
  };

  const currentQ = questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === questions.length - 1;

  return (
    <div className="space-y-8 max-w-4xl mx-auto pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold mb-2">
            <Award className="w-3.5 h-3.5" />
            <span>Interactive Assessment Engine</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white">Prompt Engineering Quizzes</h1>
          <p className="text-sm text-slate-400 max-w-xl">
            Test and benchmark your knowledge across foundational NLP concepts, few-shot schemas, and hallucination mitigation.
          </p>
        </div>

        {/* View Switcher */}
        <div className="flex items-center gap-2 p-1 rounded-xl bg-slate-900 border border-slate-800">
          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeTab === 'quiz' ? 'bg-brand-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Take Quiz
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              activeTab === 'history' ? 'bg-brand-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Past Attempts ({history.length})
          </button>
        </div>
      </div>

      {activeTab === 'quiz' ? (
        <>
          {/* Topic Selector Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            <button
              onClick={() => handleTopicChange('all')}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                selectedTopic === 'all'
                  ? 'bg-brand-600 text-white shadow-md shadow-brand-600/20'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              Master Comprehensive Quiz
            </button>
            {topics.map((t) => (
              <button
                key={t.id}
                onClick={() => handleTopicChange(t.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                  selectedTopic === t.id
                    ? 'bg-brand-600 text-white shadow-md shadow-brand-600/20'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                Module 0{t.number}: {t.title.split(' ')[0]}
              </button>
            ))}
          </div>

          {loading ? (
            <LoadingSpinner text="Loading quiz questions..." size="lg" />
          ) : result ? (
            /* Results Screen */
            <div className="glass-card rounded-3xl p-6 sm:p-10 border border-slate-800 space-y-8 animate-fade-in">
              <div className="text-center space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-brand-600 to-indigo-500 text-white flex items-center justify-center mx-auto shadow-xl shadow-brand-500/20">
                  <Award className="w-8 h-8" />
                </div>
                <h2 className="text-2xl font-black text-white">Quiz Completed!</h2>
                <div className="text-4xl font-extrabold text-brand-400">
                  {result.percentage}%
                </div>
                <p className="text-xs text-slate-300">
                  You answered {result.score} out of {result.total_questions} questions correctly.
                </p>
              </div>

              {/* Areas to Improve */}
              {result.areas_to_improve && (
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                    Recommended Areas to Review:
                  </span>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {result.areas_to_improve.map((area, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <span className="text-amber-400 font-bold">•</span>
                        <span>{area}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Detailed Breakdown */}
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Question Breakdown & Explanations:
                </h3>
                {result.feedback.map((item, idx) => (
                  <div
                    key={item.question_id}
                    className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">
                        {idx + 1}. {item.question}
                      </span>
                      {item.is_correct ? (
                        <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                          <CheckCircle2 className="w-4 h-4" /> Correct
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-rose-400 font-semibold">
                          <XCircle className="w-4 h-4" /> Incorrect
                        </span>
                      )}
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 leading-relaxed">
                      <span className="font-semibold text-brand-400">Explanation: </span>
                      {item.explanation}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  onClick={() => fetchQuestions(selectedTopic)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs transition"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retake Quiz</span>
                </button>

                <Link
                  to="/learn"
                  className="flex items-center gap-2 text-xs font-semibold text-brand-400 hover:text-brand-300 transition"
                >
                  <span>Review Curriculum</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          ) : questions.length > 0 && currentQ ? (
            /* Active Question Screen */
            <div className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-6">
              {/* Question Progress Header */}
              <div className="flex items-center justify-between text-xs pb-4 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Badge color="blue">{currentQ.type.replace('_', ' ').toUpperCase()}</Badge>
                  {currentQ.topic_title && (
                    <span className="text-slate-400">{currentQ.topic_title}</span>
                  )}
                </div>
                <span className="font-mono text-slate-400">
                  Question {currentQuestionIndex + 1} of {questions.length}
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-brand-500 rounded-full transition-all duration-300"
                  style={{
                    width: `${((currentQuestionIndex + 1) / questions.length) * 100}%`,
                  }}
                />
              </div>

              {/* Question Text */}
              <h3 className="text-lg sm:text-xl font-bold text-white leading-snug">
                {currentQ.question}
              </h3>

              {/* Options */}
              <div className="space-y-3">
                {currentQ.options.map((option, idx) => {
                  const isSelected = answers[currentQ.id] === idx;
                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelectOption(idx)}
                      className={`w-full p-4 rounded-xl text-left text-xs sm:text-sm transition border flex items-center justify-between ${
                        isSelected
                          ? 'border-brand-500 bg-brand-500/10 text-white font-medium shadow-md shadow-brand-500/10'
                          : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700 hover:text-white'
                      }`}
                    >
                      <span>{option}</span>
                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ml-3 ${
                          isSelected ? 'border-brand-500 bg-brand-500' : 'border-slate-700'
                        }`}
                      >
                        {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Footer Controls */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  onClick={() => setCurrentQuestionIndex((prev) => Math.max(prev - 1, 0))}
                  disabled={currentQuestionIndex === 0}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white disabled:opacity-30 transition"
                >
                  Previous
                </button>

                {!isLastQuestion ? (
                  <button
                    onClick={() =>
                      setCurrentQuestionIndex((prev) => Math.min(prev + 1, questions.length - 1))
                    }
                    className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-semibold text-xs transition shadow-md shadow-brand-600/20"
                  >
                    <span>Next Question</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    onClick={handleSubmit}
                    disabled={submitting || Object.keys(answers).length === 0}
                    className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-semibold text-xs transition shadow-md shadow-emerald-600/20"
                  >
                    <span>{submitting ? 'Grading...' : 'Submit Answers'}</span>
                    <Award className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center py-16 text-slate-400 text-xs">
              No questions found for this topic.
            </div>
          )}
        </>
      ) : (
        /* History View */
        <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <History className="w-5 h-5 text-amber-400" />
            <span>Past Quiz Attempts</span>
          </h3>

          <div className="space-y-3">
            {history.map((att) => (
              <div
                key={att.id}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">{att.topic.toUpperCase()}</span>
                    <Badge color={att.percentage >= 70 ? 'emerald' : 'amber'}>
                      {att.percentage}%
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-400">
                    {att.score} / {att.total_questions} correct
                  </p>
                </div>
                <div className="text-xs text-slate-400">
                  {new Date(att.created_at).toLocaleDateString()}
                </div>
              </div>
            ))}

            {history.length === 0 && (
              <div className="text-center py-12 text-slate-400 text-xs">
                No past quiz attempts recorded. Complete a quiz to view your score history!
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default QuizPage;
