import re
import json
import logging
from typing import Dict, Any, List
from app.services.llm_service import query_llm_api, is_api_configured

logger = logging.getLogger(__name__)

PRACTICE_CHALLENGES = [
    {
        "id": "challenge-1",
        "title": "Research Paper Summarizer",
        "category": "Academic & Research",
        "difficulty": "Beginner",
        "description": "Write a prompt that asks an AI to summarize a research paper in five bullet points.",
        "ideal_criteria": "Assigns a researcher/academic role, specifies 5 bullet points, requests primary methodology and findings, mentions audience, and adds a constraint to avoid technical jargon.",
        "sample_good_prompt": "You are an expert academic research assistant. Summarize the key findings of the attached research paper on climate modeling into exactly five bullet points. Focus on: (1) Core hypothesis, (2) Methodology, (3) Main finding, (4) Practical implications, and (5) Study limitations. Use clear language accessible to an undergraduate science student. Keep each bullet point to a maximum of 30 words."
    },
    {
        "id": "challenge-2",
        "title": "Customer Support Triage Agent",
        "category": "Customer Support",
        "difficulty": "Intermediate",
        "description": "Write a prompt for an AI agent to analyze an angry customer support email, classify urgency, identify product issues, and draft an empathetic response.",
        "ideal_criteria": "Includes role, sentiment classification, JSON or structured output format, empathy guidelines, and an escalation trigger for severe complaints.",
        "sample_good_prompt": "You are a senior customer care specialist for an e-commerce platform. Read the customer email below. Output a structured JSON response containing: 'urgency_level' (Low, Medium, High, Critical), 'primary_complaints' (list of identified issues), 'suggested_action' (refund, replacement, or escalation), and 'draft_response' (an empathetic 3-paragraph reply acknowledging frustration, stating immediate remediation steps, and offering direct contact details)."
    },
    {
        "id": "challenge-3",
        "title": "Few-Shot Sentiment Classifier",
        "category": "NLP & Classification",
        "difficulty": "Intermediate",
        "description": "Write a prompt that uses few-shot prompting (at least 2 examples) to classify product reviews into Positive, Negative, or Mixed with an explanation.",
        "ideal_criteria": "Uses at least two distinct input-output demonstrations, includes an explanation field, and provides clear output syntax for downstream parsing.",
        "sample_good_prompt": "Classify the sentiment of customer reviews into [POSITIVE, NEGATIVE, MIXED] and provide a one-sentence rationale.\n\nExample 1:\nReview: 'Screen is vibrant and battery lasts 14 hours. Love it!'\nSentiment: POSITIVE\nRationale: Expresses clear satisfaction with display quality and battery life.\n\nExample 2:\nReview: 'Arrived broken in box. Zero response from seller for 4 days.'\nSentiment: NEGATIVE\nRationale: Damaged merchandise combined with unacceptable customer support failure.\n\nReview to classify:\n[INSERT REVIEW]"
    },
    {
        "id": "challenge-4",
        "title": "Code Refactoring & Security Audit",
        "category": "Software Engineering",
        "difficulty": "Advanced",
        "description": "Write a prompt that instructs an AI to refactor a Python SQL query script to prevent SQL injection, use parameterized queries, and provide unit tests.",
        "ideal_criteria": "Identifies vulnerability, specifies parameterized queries or ORM, requests step-by-step security breakdown, and asks for pytest unit tests.",
        "sample_good_prompt": "You are a Principal Application Security Engineer. Audit the following Python database function for vulnerabilities. Provide: (1) An identification of all security risks including SQL injection, (2) A refactored version of the function using secure parameterized queries with SQLAlchemy, (3) Detailed explanation of the architectural improvements, and (4) Three comprehensive pytest unit test cases covering valid queries, special character handling, and error handling."
    },
    {
        "id": "challenge-5",
        "title": "JSON Data Extractor",
        "category": "Data Engineering",
        "difficulty": "Beginner",
        "description": "Write a prompt to extract dates, invoice numbers, total amounts, and vendor names from unstructured receipts into valid JSON.",
        "ideal_criteria": "Specifies strict JSON output, defines schema keys, handles missing data with null, and prohibits conversational markdown or commentary outside the JSON.",
        "sample_good_prompt": "You are a financial data extraction engine. Extract invoice details from the text below into raw JSON format. Return ONLY a valid JSON object with the following schema: { 'vendor_name': string, 'invoice_number': string, 'invoice_date': 'YYYY-MM-DD', 'subtotal': float, 'tax': float, 'total_amount': float, 'line_items': [{'description': string, 'amount': float}] }. If any field is missing or ambiguous, set its value to null. Do not include markdown fences or any conversational preambles."
    }
]

def get_all_challenges():
    return PRACTICE_CHALLENGES

def analyze_prompt_heuristically(challenge_text: str, user_prompt: str) -> Dict[str, Any]:
    """
    Detailed heuristic evaluation engine that scores the submitted prompt on 5 core dimensions:
    - Clarity (0-20)
    - Context (0-20)
    - Specificity (0-20)
    - Constraints (0-20)
    - Output Format (0-20)
    Total score: 0-100.
    """
    text = user_prompt.strip()
    words = text.split()
    word_count = len(words)
    text_lower = text.lower()

    # 1. Clarity (0 - 20)
    clarity_score = 10
    clarity_notes = []
    if word_count < 10:
        clarity_score = 6
        clarity_notes.append("The prompt is very terse; add more explanatory guidance.")
    elif 25 <= word_count <= 180:
        clarity_score = 18
        clarity_notes.append("Prompt instructions are articulate, well-paced, and easy for an LLM to parse.")
    else:
        clarity_score = 15
        clarity_notes.append("Good length, but ensure sentences are concise and avoid run-on phrasing.")

    if any(q in text_lower for q in ["please", "can you", "could you"]):
        clarity_score = max(clarity_score - 2, 10)
        clarity_notes.append("Avoid conversational pleasantries ('Please', 'Can you'); use direct imperative verbs ('Summarize', 'Extract', 'Analyze').")

    # 2. Context (0 - 20)
    context_score = 10
    context_notes = []
    has_role = any(r in text_lower for r in ["you are", "act as", "role:", "expert", "as a ", "specialist", "assistant"])
    has_background = any(b in text_lower for b in ["background", "context", "given the", "scenario", "assuming", "attached", "provided"])
    has_audience = any(a in text_lower for a in ["audience", "student", "beginner", "executive", "user", "reader", "client", "developer"])

    if has_role:
        context_score += 4
    else:
        context_notes.append("Assign an explicit persona or role (e.g., 'You are a senior research analyst...').")

    if has_background:
        context_score += 3
    else:
        context_notes.append("Provide explicit background context or indicate where source text will be injected.")

    if has_audience:
        context_score += 3
    else:
        context_notes.append("Specify the target audience to calibrate reading level and tone.")

    context_score = min(max(context_score, 8), 20)
    if not context_notes:
        context_notes.append("Strong contextual grounding with appropriate persona and target audience.")

    # 3. Specificity (0 - 20)
    specificity_score = 11
    specificity_notes = []
    num_matches = re.findall(r'\b\d+\b', text)
    if num_matches:
        specificity_score += 4
    else:
        specificity_notes.append("Include numerical targets (e.g., '5 bullet points', 'under 200 words').")

    action_verbs = ["extract", "summarize", "classify", "refactor", "audit", "compare", "evaluate", "generate", "transform"]
    found_verbs = [v for v in action_verbs if v in text_lower]
    if len(found_verbs) >= 2:
        specificity_score += 4
    elif len(found_verbs) == 1:
        specificity_score += 2
    else:
        specificity_notes.append("Use precise operational action verbs rather than open-ended requests ('tell me about').")

    specificity_score = min(max(specificity_score, 8), 20)
    if not specificity_notes:
        specificity_notes.append("High specificity with actionable metrics and clear operational instructions.")

    # 4. Constraints (0 - 20)
    constraints_score = 10
    constraints_notes = []
    has_bounds = any(c in text_lower for c in ["do not", "never", "only", "must", "limit to", "maximum", "max", "keep under", "without"])
    has_fallback = any(f in text_lower for f in ["if not found", "if unknown", "otherwise", "fallback", "null", "if missing"])

    if has_bounds:
        constraints_score += 5
    else:
        constraints_notes.append("Define negative or boundary constraints (e.g., 'Do not invent facts', 'Limit each point to 25 words').")

    if has_fallback:
        constraints_score += 4
    else:
        constraints_notes.append("Add fallback instructions for edge cases (e.g., 'If information is missing, output UNKNOWN').")

    constraints_score = min(max(constraints_score, 8), 20)
    if not constraints_notes:
        constraints_notes.append("Well-defined boundaries, length limits, and edge-case guardrails.")

    # 5. Output Format (0 - 20)
    output_score = 10
    output_notes = []
    has_format = any(f in text_lower for f in ["json", "bullet", "bullets", "markdown", "table", "schema", "xml", "csv", "numbered list", "columns"])
    
    if has_format:
        output_score += 7
    else:
        output_notes.append("Explicitly state the required output format (e.g., Markdown table, JSON schema, or numbered list).")

    if "json" in text_lower and not any(k in text_lower for k in ["schema", "keys", "format:", "{", "}"]):
        output_notes.append("When requesting JSON, explicitly provide the expected keys/schema.")
        output_score += 1
    elif "json" in text_lower and any(k in text_lower for k in ["schema", "keys", "format:", "{"]):
        output_score += 3

    output_score = min(max(output_score, 8), 20)
    if not output_notes:
        output_notes.append("Clear, unambiguous output structure with specified formatting.")

    # Total Score out of 100
    total_score = clarity_score + context_score + specificity_score + constraints_score + output_score

    # Compile actionable suggestions
    all_suggestions = []
    for notes in [clarity_notes, context_notes, specificity_notes, constraints_notes, output_notes]:
        for n in notes:
            if not any(good in n.lower() for good in ["strong", "well-defined", "high", "articulate"]):
                all_suggestions.append(n)

    if not all_suggestions:
        all_suggestions = [
            "Test the prompt with diverse edge cases to verify consistency.",
            "Consider adding one few-shot demonstration if output formatting needs strict compliance."
        ]

    # Generate an improved rewrite based on the prompt & challenge
    improved_prompt = f"""### Role:
You are an expert AI assistant specializing in clear, structured analytical communication.

### Context & Task:
{challenge_text}

### Instructions:
- Decompose the source input systematically.
- Ensure all assertions are faithful and directly grounded in the provided text.
- Target an educated, non-specialist audience.

### Output Constraints:
- Provide exactly 5 concise bullet points.
- Maximum 30 words per bullet point.
- If essential information is absent or ambiguous, clearly state [INSUFFICIENT DATA].
- Do not include conversational greetings or conversational closings."""

    # Generate simulated LLM response
    simulated_output = """• Core Objective: The paper investigates self-attention scaling efficiency in distributed transformer architectures across 1,000+ GPU nodes.
• Methodology: Researchers implemented kernel-fused FlashAttention combined with 8-bit quantized key-value caches to reduce memory bandwidth bottlenecks.
• Key Finding: Memory consumption during long-context inference (128k tokens) dropped by 64% while maintaining 99.8% baseline evaluation accuracy.
• Practical Implication: Enables mid-sized engineering teams to host long-document summarization models on single-node hardware without expensive clusters.
• Primary Limitation: Throughput gains diminish when batch sizes fall below 4 due to kernel launch overhead."""

    return {
        "score": total_score,
        "clarity": {"score": clarity_score, "max_score": 20, "comment": clarity_notes[0] if clarity_notes else "Clear formulation"},
        "context": {"score": context_score, "max_score": 20, "comment": context_notes[0] if context_notes else "Sufficient background"},
        "specificity": {"score": specificity_score, "max_score": 20, "comment": specificity_notes[0] if specificity_notes else "Good specificity"},
        "constraints": {"score": constraints_score, "max_score": 20, "comment": constraints_notes[0] if constraints_notes else "Defined boundaries"},
        "output_format": {"score": output_score, "max_score": 20, "comment": output_notes[0] if output_notes else "Explicit format"},
        "suggestions": all_suggestions[:4],
        "improved_prompt": improved_prompt,
        "simulated_output": simulated_output
    }

async def evaluate_user_prompt(challenge: str, user_prompt: str) -> Dict[str, Any]:
    """
    Evaluates the prompt using external LLM if configured, otherwise uses the
    analytical heuristic scoring engine.
    """
    if is_api_configured():
        eval_system_prompt = """You are an expert prompt engineering evaluation rubric.
Evaluate the user's submitted prompt on:
1. Clarity (0-20)
2. Context (0-20)
3. Specificity (0-20)
4. Constraints (0-20)
5. Output Format (0-20)
Total Score = sum of the 5 scores (out of 100).

Return ONLY valid JSON matching this schema:
{
  "score": number,
  "clarity": {"score": number, "comment": string},
  "context": {"score": number, "comment": string},
  "specificity": {"score": number, "comment": string},
  "constraints": {"score": number, "comment": string},
  "output_format": {"score": number, "comment": string},
  "suggestions": [string, string, string],
  "improved_prompt": string,
  "simulated_output": string
}"""
        messages = [
            {"role": "system", "content": eval_system_prompt},
            {"role": "user", "content": f"Challenge: {challenge}\nUser's Prompt: {user_prompt}"}
        ]
        api_res = await query_llm_api(messages, temperature=0.2)
        if api_res:
            try:
                # Strip markdown code blocks if present
                clean_json = api_res.strip()
                if clean_json.startswith("```json"):
                    clean_json = clean_json[7:]
                if clean_json.startswith("```"):
                    clean_json = clean_json[3:]
                if clean_json.endswith("```"):
                    clean_json = clean_json[:-3]
                data = json.loads(clean_json.strip())
                return data
            except Exception as e:
                logger.warning(f"Failed to parse LLM evaluation JSON: {e}, falling back to analytical engine.")

    return analyze_prompt_heuristically(challenge, user_prompt)
