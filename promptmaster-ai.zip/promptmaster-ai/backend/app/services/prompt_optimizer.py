import json
import logging
from typing import Dict, Any, List
from app.services.llm_service import query_llm_api, is_api_configured

logger = logging.getLogger(__name__)

def generate_structured_prompt_offline(data: Dict[str, Any]) -> Dict[str, Any]:
    """Generates a high-quality structured prompt from form parameters."""
    role = data.get("role") or "You are an expert AI assistant specializing in clear, structured analysis."
    task = data.get("task", "").strip()
    goal = data.get("goal", "").strip()
    context = data.get("context", "").strip()
    audience = data.get("audience", "").strip()
    constraints = data.get("constraints", "").strip()
    desired_format = data.get("desired_format") or "Clean Markdown with clear section headers"
    examples = data.get("examples", "").strip()

    reqs = []
    if goal:
        reqs.append(f"Achieve the primary objective: {goal}")
    if audience:
        reqs.append(f"Tailor language, tone, and terminology for: {audience}")
    if constraints:
        for c in constraints.split("\n"):
            c_clean = c.strip(" -*•")
            if c_clean:
                reqs.append(c_clean)
    else:
        reqs.append("Maintain rigorous factual consistency and avoid unsubstantiated claims.")
        reqs.append("Ensure logical flow from premise to conclusion.")

    # Build prompt string
    prompt_lines = [
        f"### Role:\n{role}\n",
        f"### Task:\n{task}\n"
    ]

    if context:
        prompt_lines.append(f"### Context & Background:\n{context}\n")

    prompt_lines.append("### Requirements & Constraints:")
    for r in reqs:
        prompt_lines.append(f"- {r}")
    prompt_lines.append("")

    prompt_lines.append(f"### Desired Output Format:\n{desired_format}\n")

    if examples:
        prompt_lines.append(f"### Demonstrations / Few-Shot Examples:\n{examples}\n")

    prompt_lines.append("### Execution Directive:\nBegin directly with the requested output according to the format above. Do not include conversational filler.")

    optimized_str = "\n".join(prompt_lines)

    return {
        "optimized_prompt": optimized_str,
        "role": role,
        "task": task,
        "context": context or "Standard enterprise context",
        "requirements": reqs,
        "output_format": desired_format,
        "explanation": "Formulated using the 4-tier Role-Task-Constraint-Format design pattern with explicit delimiters to maximize model attention alignment."
    }

async def generate_optimized_prompt(data: Dict[str, Any]) -> Dict[str, Any]:
    """Generates an optimized prompt using external LLM or structural synthesis."""
    if is_api_configured():
        system_prompt = """You are a Principal Prompt Architect.
Given the user's requirements (task, role, context, goal, constraints, format), generate a world-class production prompt.
Format the output as valid JSON matching:
{
  "optimized_prompt": "the full production-grade prompt string with markdown headers",
  "role": "extracted/enhanced role",
  "task": "refined task statement",
  "context": "context summary",
  "requirements": ["req1", "req2", "req3"],
  "output_format": "specified format",
  "explanation": "why this prompt structure works well"
}"""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": json.dumps(data)}
        ]
        api_res = await query_llm_api(messages, temperature=0.3)
        if api_res:
            try:
                clean_json = api_res.strip()
                if clean_json.startswith("```json"):
                    clean_json = clean_json[7:]
                if clean_json.startswith("```"):
                    clean_json = clean_json[3:]
                if clean_json.endswith("```"):
                    clean_json = clean_json[:-3]
                return json.loads(clean_json.strip())
            except Exception as e:
                logger.warning(f"Error parsing LLM optimizer response: {e}")

    return generate_structured_prompt_offline(data)

async def improve_existing_prompt(raw_prompt: str, focus: str = "clarity and structure") -> Dict[str, Any]:
    """Improves an existing prompt by adding structural delimiters, roles, and constraints."""
    if is_api_configured():
        system_prompt = f"""You are a master prompt refactorer.
Improve the user's prompt to make it significantly more precise, reliable, and effective.
Focus area: {focus}.
Return ONLY valid JSON:
{{
  "original_prompt": string,
  "improved_prompt": string,
  "improvements_made": [string, string, string],
  "rationale": string
}}"""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": raw_prompt}
        ]
        api_res = await query_llm_api(messages, temperature=0.3)
        if api_res:
            try:
                clean_json = api_res.strip()
                if clean_json.startswith("```json"):
                    clean_json = clean_json[7:]
                if clean_json.startswith("```"):
                    clean_json = clean_json[3:]
                if clean_json.endswith("```"):
                    clean_json = clean_json[:-3]
                return json.loads(clean_json.strip())
            except Exception as e:
                logger.warning(f"Error parsing LLM prompt improver response: {e}")

    # Offline intelligent refactoring
    improved = f"""### Role:
You are an expert specialist in this subject domain.

### Primary Directive:
{raw_prompt.strip()}

### Execution Guidelines:
1. Deconstruct the problem step by step before generating the final deliverable.
2. Ensure factual grounding and cite relevant technical principles where applicable.
3. Eliminate conversational filler or pleasantries.

### Output Constraints:
- Structure the response with clear hierarchical Markdown headers (`##`, `###`).
- Highlight critical takeaways or definitions in **bold**.
- Conclude with a 'Key Caveats & Limitations' section."""

    return {
        "original_prompt": raw_prompt,
        "improved_prompt": improved,
        "improvements_made": [
            "Assigned an authoritative domain expert persona.",
            "Converted open-ended phrasing into an actionable primary directive.",
            "Enforced step-by-step reasoning (Chain-of-Thought) to eliminate logical leaps.",
            "Added explicit Markdown formatting and limitation disclosure constraints."
        ],
        "rationale": "Unstructured prompts frequently suffer from conversational verbosity and inconsistent format. Adding explicit markdown delimiters and step-by-step guidance aligns attention weights and guarantees repeatable outputs."
    }
