import os
import json
import logging
import httpx
from typing import List, Dict, Any, Optional
from app.config import settings

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are PromptMaster AI, an educational assistant specializing in prompt engineering, NLP, machine learning, and large language models.

Teach concepts clearly and progressively.

When answering:
1. Give a simple explanation.
2. Explain the technical concept.
3. Provide a practical example.
4. Explain when it is useful.
5. Mention important limitations.
6. Use examples when helpful.
7. Do not invent facts.
8. Distinguish established facts from uncertain or model-generated information.
9. Encourage experimentation and evaluation of prompts.
10. For safety-sensitive domains, provide appropriate limitations and encourage qualified human oversight.

Format your responses with clean Markdown headers, bullet points, and code blocks for readability."""

def is_api_configured() -> bool:
    """Check if a real LLM API key has been supplied."""
    key = settings.LLM_API_KEY.strip()
    return bool(key and key != "your_api_key" and not key.startswith("your_"))

async def query_llm_api(messages: List[Dict[str, str]], temperature: float = 0.7, max_tokens: int = 1500) -> Optional[str]:
    """Call the OpenAI-compatible LLM endpoint."""
    if not is_api_configured():
        return None

    headers = {
        "Authorization": f"Bearer {settings.LLM_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": settings.LLM_MODEL,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens
    }

    url = f"{settings.LLM_BASE_URL.rstrip('/')}/chat/completions"

    try:
        async with httpx.AsyncClient(timeout=45.0) as client:
            response = await client.post(url, json=payload, headers=headers)
            if response.status_code == 200:
                data = response.json()
                return data["choices"][0]["message"]["content"]
            else:
                logger.warning(f"LLM API returned {response.status_code}: {response.text}")
                return None
    except Exception as e:
        logger.error(f"Error calling LLM API: {str(e)}")
        return None

def generate_educational_fallback(user_query: str) -> str:
    """
    Intelligent built-in PromptMaster AI knowledge generator.
    Provides structured 4-part educational explanations when no external API key is active.
    """
    query_lower = user_query.lower()

    if "zero-shot" in query_lower or "zero shot" in query_lower:
        return """### 1. Simple Explanation
**Zero-Shot Prompting** means asking an AI model to complete a task without giving it any prior examples of that task. You provide only the instruction or question, and the model relies entirely on the knowledge it gained during its pretraining.

### 2. Technical Concept
In transformer architectures, zero-shot inference tests the model's out-of-the-box parameter representations. When provided with an instruction sequence, the self-attention layers condition the autoregressive generation strictly on the semantic meaning of the task description without relying on in-context demonstrations (In-Context Learning).

### 3. Practical Example
```markdown
Classify the sentiment of the following customer feedback into Positive, Negative, or Neutral:

"The delivery arrived 2 days earlier than scheduled and the setup took less than five minutes."

Sentiment:
```
**Output:** `Positive`

### 4. Real-World Application
Zero-shot prompting is commonly used in automated email triage systems to classify incoming customer inquiries into broad categories (e.g., Billing, Technical Support, Returns) without needing a custom dataset for every category.

### 5. Important Limitations & Points
* **Ambiguity:** If the classification criteria are nuanced or non-standard, the model may choose an unexpected label.
* **Format Variations:** Zero-shot prompts may return conversational text (e.g., "The sentiment is positive because...") when you only need a single word.
* **Tip:** When zero-shot results are inconsistent, transition to Few-Shot Prompting by adding 2-3 input-output examples."""

    elif "few-shot" in query_lower or "few shot" in query_lower or "one-shot" in query_lower or "one shot" in query_lower:
        return """### 1. Simple Explanation
**Few-Shot Prompting** (and One-Shot Prompting) is a technique where you provide the AI with one or more concrete examples of inputs and desired outputs before asking it to solve your new request. It is like showing someone a couple of completed sample worksheets before asking them to do the real test.

### 2. Technical Concept
Few-shot prompting harnesses **In-Context Learning (ICL)**. Without updating any model weights (no gradient descent or backpropagation), the Transformer attends to the pattern in the prompt context. The query-key dot products anchor the output syntax and semantic style to the demonstrations provided.

### 3. Practical Example
```markdown
Extract product names and prices into structured JSON:

Input: "I bought the UltraClean Vacuum for $249 and a spare filter for $19."
Output: [{"item": "UltraClean Vacuum", "price": 249}, {"item": "spare filter", "price": 19}]

Input: "Purchased SoundWave Headphones for $120."
Output: [{"item": "SoundWave Headphones", "price": 120}]

Input: "Order details: 2 units of DeskLamp Pro at $45 each."
Output:
```

### 4. Real-World Application
Used extensively in data pipelines to convert unstructured emails, invoices, and resumes into machine-readable JSON or database records with near-zero error rates.

### 5. Important Limitations & Points
* **Context Consumption:** Few-shot examples consume prompt tokens, which increases API cost and latency.
* **Recency Bias:** Models sometimes overweight the final example in the demonstration list.
* **Label Skew:** If all your few-shot examples demonstrate positive sentiment, the model may become artificially biased toward predicting positive outcomes."""

    elif "chain of thought" in query_lower or "chain-of-thought" in query_lower or "cot" in query_lower:
        return """### 1. Simple Explanation
**Chain-of-Thought (CoT)** prompting is a technique where you instruct the AI to show its intermediate reasoning step by step before reaching a final conclusion, rather than rushing directly to an answer.

### 2. Technical Concept
Autoregressive LLMs predict subsequent tokens conditioned on previous tokens. When asked for an immediate answer to a complex math or logic problem, the model cannot backtrack if its first token is inaccurate. By generating intermediate reasoning tokens ("thinking out loud"), each successive calculation attends to previous verified logical steps.

### 3. Practical Example
```markdown
Problem: A software subscription costs $120/year per seat. A company has 25 employees. If they sign a 2-year contract today, they receive a 15% discount on the total. What is the total cost?

Let's think step by step:
1. Base annual cost for 25 seats: 25 * $120 = $3,000 per year.
2. Base cost for 2 years: $3,000 * 2 = $6,000.
3. Discount calculation: 15% of $6,000 = 0.15 * 6000 = $900.
4. Total discounted cost: $6,000 - $900 = $5,100.

Final Answer: $5,100
```

### 4. Real-World Application
Chain-of-Thought is indispensable in financial modeling, legal analysis, automated unit-test generation, and complex symbolic logic.

### 5. Important Limitations & Points
* **Higher Latency & Cost:** Writing out reasoning tokens increases response time and token billing.
* **Faithfulness:** Occasionally a model might hallucinate flawed intermediate reasoning that happens to lead to the correct answer by coincidence.
* **Best Practice:** Ask the model to wrap its internal steps in `<thinking>` tags and the final result in `<answer>` tags for clean software parsing."""

    elif "hallucination" in query_lower or "hallucinate" in query_lower:
        return """### 1. Simple Explanation
**Hallucination** in LLMs occurs when the model generates statements that sound confident, persuasive, and plausible, but are factually incorrect or completely fabricated.

### 2. Technical Concept
LLMs are statistical sequence predictors trained to maximize conditional likelihood P(w_t | w_<t). They have no innate epistemological model of empirical reality—they predict words that sound statistically probable in context, not verified facts from a relational database.

### 3. Practical Example & Mitigation Prompt
```markdown
Context:
The Helios-IV probe was launched in March 2021 by the European Solar Consortium to study coronal mass ejections. Its primary mission lasted 18 months.

Instruction:
Answer the question below using ONLY the facts explicitly provided in the Context above.
If the answer cannot be found in the Context, respond with exactly: "INSUFFICIENT INFORMATION".
Do not extrapolate.

Question: Who was the lead flight director for the Helios-IV mission?
Answer:
```
**Output:** `INSUFFICIENT INFORMATION`

### 4. Real-World Application
Mitigating hallucination is vital in legal brief drafting, medical literature summarization, and customer-facing banking chatbots.

### 5. Important Limitations & Points
* **Grounding:** Always supply the source documents in the prompt (Retrieval-Augmented Generation / RAG).
* **Negative Constraints:** Instruct the model: "If the context doesn't contain the answer, say 'I do not have enough information'."
* **Temperature:** Set temperature to 0.0 for factual lookups."""

    elif "fine tuning" in query_lower or "fine-tuning" in query_lower or "fine tune" in query_lower:
        return """### 1. Simple Explanation
**Fine-Tuning** is the process of taking a general pretrained language model and training it further on a specialized dataset to adapt its internal weights for a specific tone, task, or terminology. In contrast, **Prompt Engineering** changes only the text input without modifying any model weights.

### 2. Technical Concept
Fine-tuning uses backpropagation and gradient descent to update neural network weights on supervised input-output pairs (Supervised Fine-Tuning or SFT), or optimizes behavior via Reinforcement Learning from Human Feedback (RLHF) and Direct Preference Optimization (DPO). Techniques like LoRA (Low-Rank Adaptation) freeze 99% of parameters and train tiny adapter matrices.

### 3. Practical Example: Prompting vs Fine-Tuning
| Dimension | Prompt Engineering | Fine-Tuning |
| :--- | :--- | :--- |
| **Setup Time** | Minutes | Days to weeks |
| **Compute Cost** | Zero training cost | GPU cluster required |
| **Knowledge Updates** | Instant (edit prompt) | Requires retraining |
| **Best For** | Reasoning, dynamic facts (RAG), prototyping | Specialized tone, proprietary syntax, reducing prompt token costs |

### 4. Real-World Application
Used by healthcare providers to train models to output medical charts in exact HL7/FHIR compliance, or by game developers to teach NPC dialogue in a consistent fictional accent.

### 5. Important Limitations & Points
* **Do not fine-tune for facts:** Fine-tuning is poor at teaching dynamic factual knowledge—use RAG instead.
* **Risk of Catastrophic Forgetting:** Over-tuning can cause models to lose broad general reasoning abilities."""

    elif "system prompt" in query_lower or "role" in query_lower:
        return """### 1. Simple Explanation
A **System Prompt** (or Role-Based Prompt) sets the foundational personality, guidelines, boundaries, and behavioral rules for an AI assistant before any user conversation starts.

### 2. Technical Concept
In chat completion APIs, the system message receives top attention priority. It conditions the model's self-attention heads to adopt a specific stylistic persona, vocabulary filter, and security boundary across all subsequent dialogue turns.

### 3. Practical Example
```markdown
System:
You are an expert Python tutor. Your goal is to help beginner students learn by asking guiding questions rather than immediately giving the full solution (Socratic method).
Never write complete homework code for the student. Provide hints and identify syntax errors gently.

User:
Can you write a function to reverse a string in Python?

Assistant:
I'd love to help you build one! To start, think about how strings in Python can be accessed like lists. Have you seen Python's slice syntax `[start:stop:step]` before? How might a negative step value help?
```

### 4. Real-World Application
Essential in enterprise SaaS chatbots, customer support avatars, and interactive educational tutors.

### 5. Important Limitations & Points
* **Prompt Injection:** Untrusted user inputs may attempt to override system prompts ("Ignore all previous instructions..."). Protect against this using XML tags and clear boundary instructions."""

    else:
        return f"""### 1. Simple Explanation
Prompt Engineering is the deliberate art and science of formulating queries, instructions, and context to guide Large Language Models (LLMs) toward precise, reliable, and useful outputs. Regarding **"{user_query}"**, effective prompt design ensures the model understands your exact intent, constraints, and target format.

### 2. Technical Concept
Modern LLMs are autoregressive Transformer models that predict the next token based on all preceding tokens in the context window:
$$P(w_t \\mid w_1, w_2, \\dots, w_{{t-1}})$$
By systematically structuring the prompt with clear personas, semantic delimiters, ground-truth context, and explicit constraints, you reduce output variance and maximize the probability of accurate answers.

### 3. Practical Example
Here is how to structure a prompt related to your inquiry:
```markdown
### Role:
You are an expert AI and NLP educator.

### Task:
Explain "{user_query}" in three progressive levels of depth:
1. Beginner (simple analogy)
2. Intermediate (architectural concept)
3. Advanced (practical code or prompt implementation)

### Constraints:
- Use clean Markdown headers.
- Keep the total response under 400 words.
- Conclude with one common pitfall to avoid.
```

### 4. Real-World Application
Systematic prompt engineering enables software teams to build automated document extractors, intelligent search assistants (RAG), code review mentors, and customer support agents with enterprise reliability.

### 5. Important Points & Best Practices
* **Be Specific:** Vague prompts yield generic answers; detailed prompts produce surgical answers.
* **Assign a Role:** Setting an expert persona primes the model with appropriate domain terminology.
* **Define the Format:** Request JSON, Markdown tables, or bullet points to ensure easy integration.
* **Iterate & Evaluate:** Treat prompts like software code—version-control them and test against diverse inputs."""

async def get_chat_response(messages: List[Dict[str, str]], topic_context: Optional[str] = None) -> str:
    """Generate assistant response with system prompt and fallback support."""
    # Build complete prompt list
    formatted_messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    
    if topic_context:
        formatted_messages.append({
            "role": "system",
            "content": f"The student is currently studying the topic: '{topic_context}'. Relate your answer to this module where appropriate."
        })
        
    for m in messages:
        formatted_messages.append({"role": m["role"], "content": m["content"]})

    # Try external API first if configured
    api_response = await query_llm_api(formatted_messages)
    if api_response:
        return api_response

    # Fallback to rich educational generator
    last_user_query = ""
    for m in reversed(messages):
        if m["role"] == "user":
            last_user_query = m["content"]
            break

    return generate_educational_fallback(last_user_query)
