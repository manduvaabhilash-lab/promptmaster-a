import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from backend or project root
env_path = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

class Settings:
    PROJECT_NAME: str = "PromptMaster AI"
    VERSION: str = "1.0.0"
    API_PREFIX: str = "/api"
    
    # AI / LLM Configuration
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")
    LLM_BASE_URL: str = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
    LLM_MODEL: str = os.getenv("LLM_MODEL", "gpt-4o-mini")
    
    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./promptmaster.db")
    
    # Security
    JWT_SECRET: str = os.getenv("JWT_SECRET", "super-secret-promptmaster-key-change-in-production-2026")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days

settings = Settings()
