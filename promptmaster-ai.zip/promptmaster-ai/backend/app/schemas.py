import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, EmailStr, Field

# User schemas
class UserCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: str = Field(..., min_length=5, max_length=255)
    password: str = Field(..., min_length=6, max_length=128)

class UserLogin(BaseModel):
    email: str = Field(..., min_length=5, max_length=255)
    password: str

class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    created_at: datetime.datetime

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse

# Chat schemas
class MessageSchema(BaseModel):
    id: int
    role: str
    content: str
    created_at: datetime.datetime

    class Config:
        from_attributes = True

class ConversationSchema(BaseModel):
    id: int
    title: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    messages: List[MessageSchema] = []

    class Config:
        from_attributes = True

class ConversationListSchema(BaseModel):
    id: int
    title: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    message_count: int = 0

    class Config:
        from_attributes = True

class ChatRequest(BaseModel):
    conversation_id: Optional[int] = None
    message: str = Field(..., min_length=1, max_length=10000)
    topic_context: Optional[str] = None

class ChatResponse(BaseModel):
    conversation_id: int
    user_message: MessageSchema
    assistant_message: MessageSchema

# Prompt Evaluation Schemas
class PromptEvaluateRequest(BaseModel):
    challenge: str = Field(..., description="Challenge title or description")
    prompt: str = Field(..., min_length=2, description="The prompt entered by user")

class MetricScore(BaseModel):
    score: int
    max_score: int = 20
    comment: str

class PromptEvaluateResponse(BaseModel):
    id: Optional[int] = None
    score: int
    clarity: MetricScore
    context: MetricScore
    specificity: MetricScore
    constraints: MetricScore
    output_format: MetricScore
    completeness: MetricScore
    suggestions: List[str]
    improved_prompt: str
    simulated_output: str

# Prompt Generator Schemas
class PromptGenerateRequest(BaseModel):
    task: str = Field(..., min_length=2)
    goal: Optional[str] = ""
    context: Optional[str] = ""
    role: Optional[str] = ""
    audience: Optional[str] = ""
    constraints: Optional[str] = ""
    desired_format: Optional[str] = ""
    examples: Optional[str] = ""

class PromptGenerateResponse(BaseModel):
    optimized_prompt: str
    role: str
    task: str
    context: str
    requirements: List[str]
    output_format: str
    explanation: str

class PromptImproveRequest(BaseModel):
    prompt: str = Field(..., min_length=5)
    target_focus: Optional[str] = "clarity and structure"

class PromptImproveResponse(BaseModel):
    original_prompt: str
    improved_prompt: str
    improvements_made: List[str]
    rationale: str

# Saved Prompt Schemas
class SavedPromptCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=255)
    content: str = Field(..., min_length=1)

class SavedPromptResponse(BaseModel):
    id: int
    user_id: Optional[int]
    title: str
    content: str
    created_at: datetime.datetime

    class Config:
        from_attributes = True

# Quiz Schemas
class QuizAnswerSubmission(BaseModel):
    question_id: int
    selected_option: int

class QuizSubmitRequest(BaseModel):
    topic: str
    answers: List[QuizAnswerSubmission]

class QuizFeedbackItem(BaseModel):
    question_id: int
    question: str
    selected_option: int
    correct_option: int
    is_correct: bool
    explanation: str

class QuizSubmitResponse(BaseModel):
    id: int
    topic: str
    score: int
    total_questions: int
    percentage: float
    feedback: List[QuizFeedbackItem]
    areas_to_improve: List[str]

class QuizAttemptHistory(BaseModel):
    id: int
    topic: str
    score: int
    total_questions: int
    percentage: float
    created_at: datetime.datetime

    class Config:
        from_attributes = True

# General AI Response Evaluation Schemas
class ResponseEvaluationRequest(BaseModel):
    prompt: str
    response: str

class ResponseEvaluationResult(BaseModel):
    accuracy_score: int
    relevance_score: int
    clarity_score: int
    completeness_score: int
    consistency_score: int
    hallucination_risk: str  # Low, Medium, High
    safety_rating: str  # Safe, Caution, Unsafe
    bias_score: int
    potential_issues: List[str]
    recommendations: List[str]
    analysis_summary: str
