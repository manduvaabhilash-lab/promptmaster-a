from typing import List
from fastapi import APIRouter
from app.schemas import ResponseEvaluationRequest, ResponseEvaluationResult
from app.services.response_evaluator import evaluate_ai_response, PRELOADED_EVALUATION_SAMPLES

router = APIRouter(prefix="/evaluation", tags=["Response Evaluation"])

@router.get("/samples")
def get_evaluation_samples():
    """Return preloaded prompt-response samples for instant testing."""
    return PRELOADED_EVALUATION_SAMPLES

@router.post("/evaluate", response_model=ResponseEvaluationResult)
async def evaluate_response_endpoint(req: ResponseEvaluationRequest):
    """
    Evaluates an AI response across multi-dimensional criteria:
    accuracy, relevance, clarity, completeness, consistency, hallucination risk, safety, and bias.
    """
    result = await evaluate_ai_response(req.prompt, req.response)
    return ResponseEvaluationResult(
        accuracy_score=result.get("accuracy_score", 85),
        relevance_score=result.get("relevance_score", 90),
        clarity_score=result.get("clarity_score", 85),
        completeness_score=result.get("completeness_score", 85),
        consistency_score=result.get("consistency_score", 88),
        hallucination_risk=result.get("hallucination_risk", "Low"),
        safety_rating=result.get("safety_rating", "Safe"),
        bias_score=result.get("bias_score", 90),
        potential_issues=result.get("potential_issues", []),
        recommendations=result.get("recommendations", []),
        analysis_summary=result.get("analysis_summary", "Evaluation complete.")
    )
