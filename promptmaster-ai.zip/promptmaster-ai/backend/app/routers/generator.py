from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import SavedPrompt, User
from app.schemas import (
    PromptGenerateRequest, PromptGenerateResponse,
    PromptImproveRequest, PromptImproveResponse,
    SavedPromptCreate, SavedPromptResponse
)
from app.auth import get_current_user_optional
from app.services.prompt_optimizer import generate_optimized_prompt, improve_existing_prompt

router = APIRouter(prefix="/prompt", tags=["Prompt Generator & Optimizer"])

@router.post("/generate", response_model=PromptGenerateResponse)
async def generate_prompt(req: PromptGenerateRequest):
    data = req.model_dump()
    result = await generate_optimized_prompt(data)
    return PromptGenerateResponse(
        optimized_prompt=result["optimized_prompt"],
        role=result.get("role", "Expert Assistant"),
        task=result.get("task", req.task),
        context=result.get("context", ""),
        requirements=result.get("requirements", []),
        output_format=result.get("output_format", ""),
        explanation=result.get("explanation", "Structured with clear role and constraints.")
    )

@router.post("/improve", response_model=PromptImproveResponse)
async def improve_prompt(req: PromptImproveRequest):
    result = await improve_existing_prompt(req.prompt, req.target_focus or "clarity and structure")
    return PromptImproveResponse(
        original_prompt=result["original_prompt"],
        improved_prompt=result["improved_prompt"],
        improvements_made=result["improvements_made"],
        rationale=result["rationale"]
    )

@router.post("/save", response_model=SavedPromptResponse)
def save_prompt(
    req: SavedPromptCreate,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    user_id = current_user.id if current_user else None
    saved = SavedPrompt(
        user_id=user_id,
        title=req.title.strip(),
        content=req.content.strip()
    )
    db.add(saved)
    db.commit()
    db.refresh(saved)
    return SavedPromptResponse.model_validate(saved)

@router.get("/saved", response_model=List[SavedPromptResponse])
def get_saved_prompts(
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    query = db.query(SavedPrompt)
    if current_user:
        query = query.filter(SavedPrompt.user_id == current_user.id)
    else:
        query = query.filter(SavedPrompt.user_id.is_(None))

    saved_list = query.order_by(SavedPrompt.created_at.desc()).all()
    return [SavedPromptResponse.model_validate(p) for p in saved_list]

@router.delete("/saved/{prompt_id}")
def delete_saved_prompt(
    prompt_id: int,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    prompt = db.query(SavedPrompt).filter(SavedPrompt.id == prompt_id).first()
    if not prompt:
        raise HTTPException(status_code=404, detail="Saved prompt not found.")

    if current_user and prompt.user_id and prompt.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized.")

    db.delete(prompt)
    db.commit()
    return {"message": "Saved prompt removed successfully."}
