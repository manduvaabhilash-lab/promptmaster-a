import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Conversation, Message, User
from app.schemas import ChatRequest, ChatResponse, ConversationSchema, ConversationListSchema, MessageSchema
from app.auth import get_current_user_optional
from app.services.llm_service import get_chat_response

router = APIRouter(prefix="/chat", tags=["Chatbot"])

@router.post("", response_model=ChatResponse)
async def send_chat_message(
    chat_req: ChatRequest,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    user_id = current_user.id if current_user else None

    # Retrieve or create conversation
    if chat_req.conversation_id:
        conversation = db.query(Conversation).filter(Conversation.id == chat_req.conversation_id).first()
        if not conversation:
            raise HTTPException(status_code=404, detail="Conversation not found.")
    else:
        # Generate initial title based on first words of query
        first_few_words = " ".join(chat_req.message.strip().split()[:5])
        title = first_few_words[:40] if first_few_words else "New Chat"
        conversation = Conversation(user_id=user_id, title=title)
        db.add(conversation)
        db.commit()
        db.refresh(conversation)

    # Save user message to database
    user_msg = Message(
        conversation_id=conversation.id,
        role="user",
        content=chat_req.message
    )
    db.add(user_msg)
    db.commit()
    db.refresh(user_msg)

    # Fetch recent conversation messages for context window
    history_msgs = (
        db.query(Message)
        .filter(Message.conversation_id == conversation.id)
        .order_by(Message.created_at.asc())
        .all()
    )

    llm_formatted_messages = [{"role": m.role, "content": m.content} for m in history_msgs]

    # Generate assistant response
    assistant_reply_text = await get_chat_response(llm_formatted_messages, chat_req.topic_context)

    # Save assistant message to database
    assistant_msg = Message(
        conversation_id=conversation.id,
        role="assistant",
        content=assistant_reply_text
    )
    db.add(assistant_msg)

    # Update conversation timestamp
    conversation.updated_at = datetime.datetime.utcnow()
    db.commit()
    db.refresh(assistant_msg)

    return ChatResponse(
        conversation_id=conversation.id,
        user_message=MessageSchema.model_validate(user_msg),
        assistant_message=MessageSchema.model_validate(assistant_msg)
    )

@router.get("/conversations", response_model=List[ConversationListSchema])
def list_conversations(
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    query = db.query(Conversation)
    if current_user:
        query = query.filter(Conversation.user_id == current_user.id)
    else:
        query = query.filter(Conversation.user_id.is_(None))

    conversations = query.order_by(Conversation.updated_at.desc()).limit(30).all()

    result = []
    for conv in conversations:
        count = db.query(Message).filter(Message.conversation_id == conv.id).count()
        result.append(ConversationListSchema(
            id=conv.id,
            title=conv.title,
            created_at=conv.created_at,
            updated_at=conv.updated_at,
            message_count=count
        ))
    return result

@router.get("/conversations/{conversation_id}", response_model=ConversationSchema)
def get_conversation_by_id(
    conversation_id: int,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    conv = db.query(Conversation).filter(Conversation.id == conversation_id).first()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found.")

    if current_user and conv.user_id and conv.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized access to conversation.")

    return ConversationSchema.model_validate(conv)

@router.delete("/conversations/{conversation_id}")
def delete_conversation(
    conversation_id: int,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    conv = db.query(Conversation).filter(Conversation.id == conversation_id).first()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found.")

    if current_user and conv.user_id and conv.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized.")

    db.delete(conv)
    db.commit()
    return {"message": "Conversation deleted successfully."}

@router.get("/history")
def get_recent_history(
    limit: int = 15,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Retrieve recent messages across all sessions."""
    query = db.query(Message).join(Conversation)
    if current_user:
        query = query.filter(Conversation.user_id == current_user.id)
    else:
        query = query.filter(Conversation.user_id.is_(None))

    recent_messages = query.order_by(Message.created_at.desc()).limit(limit).all()
    return [MessageSchema.model_validate(m) for m in reversed(recent_messages)]
