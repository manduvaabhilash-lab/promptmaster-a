import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import PromptAttempt, User
from app.schemas import PromptEvaluateRequest, PromptEvaluateResponse, MetricScore
from app.auth import get_current_user_optional
from app.services.prompt_evaluator import get_all_challenges, evaluate_user_prompt

router = APIRouter(prefix="", tags=["Prompt Practice Lab"])

@router.get("/practice/challenges")
def list_challenges():
    """Returns curated prompt practice challenges."""
    return get_all_challenges()

@router.post("/prompt/evaluate", response_model=PromptEvaluateResponse)
async def evaluate_prompt(
    req: PromptEvaluateRequest,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """
    Evaluates the submitted prompt against objective criteria:
    Clarity, Context, Specificity, Constraints, Output Format, and Completeness.
    Scores out of 100 without equating to human intelligence.
    """
    evaluation_result = await evaluate_user_prompt(req.challenge, req.prompt)

    # Convert to structured response
    clarity_obj = evaluation_result.get("clarity", {"score": 15, "comment": "Good clarity"})
    context_obj = evaluation_result.get("context", {"score": 15, "comment": "Adequate context"})
    specificity_obj = evaluation_result.get("specificity", {"score": 15, "comment": "Good detail"})
    constraints_obj = evaluation_result.get("constraints", {"score": 15, "comment": "Clear boundaries"})
    format_obj = evaluation_result.get("output_format", {"score": 15, "comment": "Output defined"})
    
    # Calculate completeness
    total_score = evaluation_result.get("score", 75)
    completeness_score = min(max(int(total_score * 0.2), 10), 20)

    feedback_payload = {
        "score": total_score,
        "clarity": clarity_obj,
        "context": context_obj,
        "specificity": specificity_obj,
        "constraints": constraints_obj,
        "output_format": format_obj,
        "completeness": {"score": completeness_score, "max_score": 20, "comment": "Addresses core task criteria"},
        "suggestions": evaluation_result.get("suggestions", []),
        "improved_prompt": evaluation_result.get("improved_prompt", ""),
        "simulated_output": evaluation_result.get("simulated_output", "")
    }

    # Save to database
    user_id = current_user.id if current_user else None
    attempt = PromptAttempt(
        user_id=user_id,
        challenge=req.challenge,
        prompt=req.prompt,
        score=total_score,
        feedback=json.dumps(feedback_payload)
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)

    return PromptEvaluateResponse(
        id=attempt.id,
        score=total_score,
        clarity=MetricScore(score=clarity_obj["score"], comment=clarity_obj.get("comment", "")),
        context=MetricScore(score=context_obj["score"], comment=context_obj.get("comment", "")),
        specificity=MetricScore(score=specificity_obj["score"], comment=specificity_obj.get("comment", "")),
        constraints=MetricScore(score=constraints_obj["score"], comment=constraints_obj.get("comment", "")),
        output_format=MetricScore(score=format_obj["score"], comment=format_obj.get("comment", "")),
        completeness=MetricScore(score=completeness_score, comment="Addresses core task requirements"),
        suggestions=evaluation_result.get("suggestions", []),
        improved_prompt=evaluation_result.get("improved_prompt", ""),
        simulated_output=evaluation_result.get("simulated_output", "")
    )

@router.get("/practice/history")
def get_practice_history(
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    query = db.query(PromptAttempt)
    if current_user:
        query = query.filter(PromptAttempt.user_id == current_user.id)
    else:
        query = query.filter(PromptAttempt.user_id.is_(None))

    attempts = query.order_by(PromptAttempt.created_at.desc()).limit(20).all()
    res = []
    for a in attempts:
        feedback_data = {}
        try:
            feedback_data = json.loads(a.feedback)
        except Exception:
            pass
        res.append({
            "id": a.id,
            "challenge": a.challenge,
            "prompt": a.prompt,
            "score": a.score,
            "feedback": feedback_data,
            "created_at": a.created_at
        })
    return res
