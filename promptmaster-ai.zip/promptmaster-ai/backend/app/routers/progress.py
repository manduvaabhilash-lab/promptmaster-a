import json
from typing import Dict, Any, List, Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app.models import User, QuizAttempt, PromptAttempt, Conversation, SavedPrompt
from app.auth import get_current_user_optional, get_current_user
from app.services.topic_content import get_all_topics

router = APIRouter(prefix="", tags=["Progress & Profile"])

@router.get("/progress")
def get_user_progress(
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    user_id = current_user.id if current_user else None

    # Quiz statistics
    quiz_query = db.query(QuizAttempt)
    if user_id:
        quiz_query = quiz_query.filter(QuizAttempt.user_id == user_id)
    else:
        quiz_query = quiz_query.filter(QuizAttempt.user_id.is_(None))

    quiz_attempts = quiz_query.all()
    total_quizzes = len(quiz_attempts)
    avg_quiz_score = round(sum(q.percentage for q in quiz_attempts) / total_quizzes, 1) if total_quizzes > 0 else 0.0

    # Prompt practice statistics
    practice_query = db.query(PromptAttempt)
    if user_id:
        practice_query = practice_query.filter(PromptAttempt.user_id == user_id)
    else:
        practice_query = practice_query.filter(PromptAttempt.user_id.is_(None))

    practice_attempts = practice_query.all()
    total_practice = len(practice_attempts)
    avg_practice_score = round(sum(p.score for p in practice_attempts) / total_practice, 1) if total_practice > 0 else 0.0

    # Conversations
    conv_query = db.query(Conversation)
    if user_id:
        conv_query = conv_query.filter(Conversation.user_id == user_id)
    else:
        conv_query = conv_query.filter(Conversation.user_id.is_(None))

    recent_convs = conv_query.order_by(Conversation.updated_at.desc()).limit(5).all()

    # Topics completed estimate
    unique_topics_quizzed = len(set(q.topic for q in quiz_attempts if q.percentage >= 60))
    total_curriculum_topics = len(get_all_topics())
    topics_completed = min(unique_topics_quizzed, total_curriculum_topics)
    overall_progress_pct = round((topics_completed / total_curriculum_topics) * 100, 1)

    # Saved prompts count
    saved_query = db.query(SavedPrompt)
    if user_id:
        saved_query = saved_query.filter(SavedPrompt.user_id == user_id)
    else:
        saved_query = saved_query.filter(SavedPrompt.user_id.is_(None))
    saved_prompts_count = saved_query.count()

    # Recommended topics
    all_topics = get_all_topics()
    completed_slugs = {q.topic for q in quiz_attempts if q.percentage >= 60}
    recommended = []
    for t in all_topics:
        if t["slug"] not in completed_slugs:
            recommended.append({
                "id": t["id"],
                "title": t["title"],
                "badge": t["badge"],
                "reading_time": t["reading_time"],
                "overview": t["overview"]
            })
    if not recommended:
        recommended = [
            {"id": all_topics[0]["id"], "title": all_topics[0]["title"], "badge": all_topics[0]["badge"], "reading_time": all_topics[0]["reading_time"], "overview": all_topics[0]["overview"]},
            {"id": all_topics[3]["id"], "title": all_topics[3]["title"], "badge": all_topics[3]["badge"], "reading_time": all_topics[3]["reading_time"], "overview": all_topics[3]["overview"]}
        ]

    return {
        "learning_progress_pct": overall_progress_pct,
        "topics_completed": topics_completed,
        "total_topics": total_curriculum_topics,
        "total_quizzes": total_quizzes,
        "avg_quiz_score": avg_quiz_score,
        "total_practice": total_practice,
        "avg_practice_score": avg_practice_score,
        "saved_prompts_count": saved_prompts_count,
        "recent_conversations": [
            {
                "id": c.id,
                "title": c.title,
                "updated_at": c.updated_at
            }
            for c in recent_convs
        ],
        "recommended_topics": recommended[:3]
    }

@router.get("/profile")
def get_user_profile(
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    if not current_user:
        # Return guest profile information
        return {
            "is_guest": True,
            "id": None,
            "name": "Guest Learner",
            "email": "guest@promptmaster.ai",
            "badges": ["Curious Explorer", "Prompt Apprentice"],
            "bio": "Exploring prompt engineering and LLM architectures."
        }

    # Calculate user accolades
    quiz_count = db.query(QuizAttempt).filter(QuizAttempt.user_id == current_user.id).count()
    practice_count = db.query(PromptAttempt).filter(PromptAttempt.user_id == current_user.id).count()

    badges = ["Prompt Apprentice"]
    if quiz_count >= 1:
        badges.append("Knowledge Seeker")
    if quiz_count >= 5:
        badges.append("Quiz Master")
    if practice_count >= 3:
        badges.append("Lab Specialist")
    if practice_count >= 10:
        badges.append("Prompt Architect")

    return {
        "is_guest": False,
        "id": current_user.id,
        "name": current_user.name,
        "email": current_user.email,
        "created_at": current_user.created_at,
        "badges": badges,
        "bio": "Prompt engineering student and AI practitioner."
    }
