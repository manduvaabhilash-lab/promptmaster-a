from typing import List
from fastapi import APIRouter, HTTPException, status
from app.services.topic_content import get_all_topics, get_topic_by_id

router = APIRouter(prefix="/topics", tags=["Topics"])

@router.get("")
def list_topics():
    """Return all 7 learning curriculum modules."""
    topics = get_all_topics()
    # Return summary representations
    return [
        {
            "id": t["id"],
            "slug": t["slug"],
            "number": t["number"],
            "title": t["title"],
            "subtitle": t["subtitle"],
            "reading_time": t["reading_time"],
            "badge": t["badge"],
            "overview": t["overview"],
            "key_concepts_count": len(t.get("key_concepts", [])),
            "examples_count": len(t.get("examples", [])),
            "quiz_questions_count": len(t.get("mini_quiz", []))
        }
        for t in topics
    ]

@router.get("/{topic_id}")
def get_topic_detail(topic_id: str):
    """Return comprehensive deep-dive data for a specific module."""
    topic = get_topic_by_id(topic_id)
    if not topic:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Topic '{topic_id}' not found."
        )
    return topic
