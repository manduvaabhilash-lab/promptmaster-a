from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import QuizAttempt, User
from app.schemas import QuizSubmitRequest, QuizSubmitResponse, QuizAttemptHistory, QuizFeedbackItem
from app.auth import get_current_user_optional
from app.services.topic_content import get_all_topics, get_topic_by_id

router = APIRouter(prefix="/quiz", tags=["Quiz System"])

def get_questions_for_topic(topic_slug: str):
    """Retrieve quiz questions for a topic, or all questions if 'all'."""
    topics = get_all_topics()
    questions = []
    
    if topic_slug == "all" or not topic_slug:
        for t in topics:
            for q in t.get("mini_quiz", []):
                q_copy = dict(q)
                q_copy["topic_id"] = t["id"]
                q_copy["topic_title"] = t["title"]
                questions.append(q_copy)
    else:
        topic = get_topic_by_id(topic_slug)
        if topic:
            for q in topic.get("mini_quiz", []):
                q_copy = dict(q)
                q_copy["topic_id"] = topic["id"]
                q_copy["topic_title"] = topic["title"]
                questions.append(q_copy)
    return questions

@router.get("/questions")
def get_quiz_questions(topic: str = "all"):
    """Fetch quiz questions without exposing the correct answer indices to client."""
    raw_questions = get_questions_for_topic(topic)
    client_questions = []
    for q in raw_questions:
        client_questions.append({
            "id": q["id"],
            "topic_id": q.get("topic_id", ""),
            "topic_title": q.get("topic_title", ""),
            "question": q["question"],
            "type": q["type"],
            "options": q["options"]
        })
    return client_questions

@router.post("/submit", response_model=QuizSubmitResponse)
def submit_quiz_attempt(
    req: QuizSubmitRequest,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    all_questions = get_questions_for_topic("all")
    q_map = {q["id"]: q for q in all_questions}

    score = 0
    feedback_items = []
    areas_to_improve = set()

    for ans in req.answers:
        q = q_map.get(ans.question_id)
        if not q:
            continue

        is_correct = (ans.selected_option == q["correct_option"])
        if is_correct:
            score += 1
        else:
            topic_name = q.get("topic_title", "Prompt Fundamentals")
            areas_to_improve.add(topic_name)

        feedback_items.append(QuizFeedbackItem(
            question_id=q["id"],
            question=q["question"],
            selected_option=ans.selected_option,
            correct_option=q["correct_option"],
            is_correct=is_correct,
            explanation=q.get("explanation", "Review the relevant module material for details.")
        ))

    total_questions = len(feedback_items) if feedback_items else 1
    percentage = round((score / total_questions) * 100, 1)

    # Save attempt to database
    user_id = current_user.id if current_user else None
    attempt = QuizAttempt(
        user_id=user_id,
        topic=req.topic,
        score=score,
        total_questions=total_questions,
        percentage=percentage
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)

    return QuizSubmitResponse(
        id=attempt.id,
        topic=req.topic,
        score=score,
        total_questions=total_questions,
        percentage=percentage,
        feedback=feedback_items,
        areas_to_improve=list(areas_to_improve) if areas_to_improve else ["Great job! All answers in this session were correct."]
    )

@router.get("/history", response_model=List[QuizAttemptHistory])
def get_quiz_history(
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    query = db.query(QuizAttempt)
    if current_user:
        query = query.filter(QuizAttempt.user_id == current_user.id)
    else:
        query = query.filter(QuizAttempt.user_id.is_(None))

    attempts = query.order_by(QuizAttempt.created_at.desc()).limit(25).all()
    return [QuizAttemptHistory.model_validate(a) for a in attempts]
