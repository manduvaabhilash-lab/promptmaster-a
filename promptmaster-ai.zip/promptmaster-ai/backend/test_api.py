import os
import sys
from fastapi.testclient import TestClient

# Ensure current working directory has access to app
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.main import app

client = TestClient(app)

def run_tests():
    print("=== PromptMaster AI Integration Test Suite ===")

    # 1. Health check
    res = client.get("/api/health")
    assert res.status_code == 200, f"Health check failed: {res.text}"
    print("[PASS] Health Check:", res.json())

    # 2. Topics list & detail
    res = client.get("/api/topics")
    assert res.status_code == 200
    topics = res.json()
    assert len(topics) == 7, f"Expected 7 curriculum topics, got {len(topics)}"
    print(f"[PASS] Topics List: {len(topics)} topics retrieved")

    res = client.get("/api/topics/fundamentals")
    assert res.status_code == 200
    assert res.json()["title"] == "Prompt Engineering Fundamentals"
    print("[PASS] Topic Detail: Fundamentals module verified")

    # 3. Auth: Register & Login
    import secrets
    test_email = f"test_{secrets.token_hex(4)}@promptmaster.ai"
    reg_payload = {"name": "Test Engineer", "email": test_email, "password": "password123"}
    res = client.post("/api/auth/register", json=reg_payload)
    assert res.status_code == 201, f"Registration failed: {res.text}"
    token = res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("[PASS] User Registration")

    login_res = client.post("/api/auth/login", json={"email": test_email, "password": "password123"})
    assert login_res.status_code == 200
    print("[PASS] User Login")

    # 4. User Profile
    res = client.get("/api/profile", headers=headers)
    assert res.status_code == 200
    assert res.json()["email"] == test_email
    print("[PASS] Profile Retrieval")

    # 5. AI Chat
    chat_payload = {"message": "What is zero-shot prompting?", "topic_context": "Prompt Engineering Fundamentals"}
    res = client.post("/api/chat", json=chat_payload, headers=headers)
    assert res.status_code == 200, f"Chat failed: {res.text}"
    chat_data = res.json()
    assert "Zero-Shot" in chat_data["assistant_message"]["content"] or len(chat_data["assistant_message"]["content"]) > 50
    conv_id = chat_data["conversation_id"]
    print("[PASS] AI Chat: Assistant replied to zero-shot query")

    # 6. Prompt Practice Evaluation
    eval_payload = {
        "challenge": "Research Paper Summarizer",
        "prompt": "You are a research scientist. Summarize the attached paper in 5 concise bullet points under 30 words each."
    }
    res = client.post("/api/prompt/evaluate", json=eval_payload, headers=headers)
    assert res.status_code == 200
    eval_data = res.json()
    assert eval_data["score"] > 0
    assert "clarity" in eval_data
    print(f"[PASS] Prompt Practice Evaluation: Prompt scored {eval_data['score']}/100")

    # 7. Prompt Generator & Optimizer
    gen_payload = {
        "task": "Extract customer billing address",
        "role": "Database ETL Parser",
        "audience": "PostgreSQL schema",
        "desired_format": "JSON Schema",
        "constraints": "Return only valid JSON"
    }
    res = client.post("/api/prompt/generate", json=gen_payload)
    assert res.status_code == 200
    gen_data = res.json()
    assert "Database ETL Parser" in gen_data["optimized_prompt"]
    print("[PASS] Prompt Generator")

    # 8. Prompt Save & Retrieve
    save_payload = {"title": "Billing Address Extractor", "content": gen_data["optimized_prompt"]}
    res = client.post("/api/prompt/save", json=save_payload, headers=headers)
    assert res.status_code == 200
    prompt_id = res.json()["id"]
    print("[PASS] Saved Prompt")

    saved_list_res = client.get("/api/prompt/saved", headers=headers)
    assert any(p["id"] == prompt_id for p in saved_list_res.json())
    print("[PASS] Saved Prompts List")

    # 9. Response Evaluation (Module 11)
    response_eval_payload = {
        "prompt": "Who walked on the moon first?",
        "response": "Neil Armstrong was the first person to walk on the moon in July 1969 during Apollo 11."
    }
    res = client.post("/api/evaluation/evaluate", json=response_eval_payload)
    assert res.status_code == 200
    assert res.json()["safety_rating"] == "Safe"
    print("[PASS] Response Evaluation")

    # 10. Quiz Questions & Submission
    res = client.get("/api/quiz/questions?topic=fundamentals")
    assert res.status_code == 200
    questions = res.json()
    assert len(questions) > 0

    quiz_sub_payload = {
        "topic": "fundamentals",
        "answers": [{"question_id": questions[0]["id"], "selected_option": 1}]
    }
    res = client.post("/api/quiz/submit", json=quiz_sub_payload, headers=headers)
    assert res.status_code == 200
    assert "percentage" in res.json()
    print("[PASS] Quiz Submission")

    # 11. Dashboard Progress
    res = client.get("/api/progress", headers=headers)
    assert res.status_code == 200
    prog_data = res.json()
    assert prog_data["total_topics"] == 7
    print(f"[PASS] Dashboard Progress: {prog_data['learning_progress_pct']}% completed")

    print("\nALL 11 TEST SUITES PASSED CLEANLY!")

if __name__ == "__main__":
    run_tests()
